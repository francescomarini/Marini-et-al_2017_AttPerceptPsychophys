function settings=SHIELD08_Initialize(runmode)

if nargin>1
    error('Too many input arguments');
end

if ~strcmp(runmode,'behavior') && ~strcmp(runmode,'eeg')
    error(['Unidentified session type. Please choose ', char(39), 'threshold', char(39), ', ', char(39), 'test', char(39), ', or ', char(39), 'restart', char(39)]);
end


%% Set path
settings.path.Experiment=fileparts(which('SHIELD08_Run'));
settings.path.Project=fileparts(settings.path.Experiment);
settings.path.Data=fullfile(settings.path.Project,'data');
addpath(genpath(settings.path.Experiment));
if ~exist(settings.path.Data,'dir'); mkdir(settings.path.Data); end

%% General data
% Experimenter control
settings.generalData.DebugMode=false; % use for debugging, runs in windowed mode
settings.generalData.NoStop=false;
settings.generalData.quickMode=false; % use for rapid testing of the entire paradigm
settings.generalData.runTable={'practice', 'experiment'};
% Settings for experiment
settings.generalData.numPracticeTrials=16; % number of practice trials
settings.generalData.numBlocks=12; % number of blocks in the experiment
settings.generalData.numTrials=384; % number of trials (total)
settings.generalData.numTrialsPerBlock=floor(settings.generalData.numTrials/settings.generalData.numBlocks);
settings.generalData.PauseBeforeTrial=settings.generalData.numTrialsPerBlock+1:settings.generalData.numTrialsPerBlock:settings.generalData.numTrials;;
% % % If practice trials is an odd number make it even
% % if mod(settings.generalData.numPracticeTrials,2)
% %     settings.generalData.numPracticeTrials=settings.generalData.numPracticeTrials+1;
% % end


%% Get user inputs
settings=GetInputs(settings);

%% Set screen values
if settings.generalData.DebugMode
    settings.screenValues.Windowed=true;
else
    settings.screenValues.Windowed=false;
end
settings.screenValues.screenNumber=max(Screen('Screens'));
% Find the color values which correspond to white and black
white=[255 255 255]; settings.screenValues.White=white;
black=[0 0 0]; settings.screenValues.Black=black;
gray=(white+black)/2; settings.screenValues.Gray=gray;
% Colors
settings.screenValues.BackgroundColor=black;
settings.screenValues.ForegroundColor=gray;
settings.screenValues.TooSlowColor=[192 0 0]; % red
% Text
settings.screenValues.FontType='Arial';
settings.screenValues.FontSize=36;
settings.screenValues.FontStyle=0;
settings.screenValues.TextColor=gray;
% Fixation
settings.screenValues.FixationSize_Pix=4; % in pixels
settings.screenValues.FixationUpdrift_Pix=0;
settings.screenValues.FixationPenWidth_Pix=2;
settings.screenValues.FixationColor=gray;
settings.screenValues.observerDistanceCM=settings.screenValues.observerDistanceInch*2.54;
 
    
%% Timings
settings.duration.Cue=0.5;
settings.duration.CueToStim=1;
settings.duration.Stimulus=0.2;
% settings.duration.Mask=0.2;
settings.duration.StimToDist=0.8;
settings.duration.Dist=0.4;
settings.duration.DistEachScreen=settings.duration.Dist;
settings.duration.DistToProbe=0.8;
settings.duration.Delay=settings.duration.StimToDist+settings.duration.Dist+settings.duration.DistToProbe;
settings.duration.maxResponse=5;
settings.duration.Probe=settings.duration.maxResponse;
settings.duration.ITI=[1 1.4]; % jittered between those values. From feedback offset to next stim onset
settings.duration.TooSlow=1;
settings.duration.Feedback=2;
if settings.generalData.quickMode
    duration_fieldnames=fieldnames(settings.duration);
    for fieldi=1:length(duration_fieldnames)
        eval(['settings.duration.' duration_fieldnames{fieldi} '=settings.duration.' duration_fieldnames{fieldi} '/10;']);
    end
end


%% Set Stimulus Parameters
% Cue
settings.stimObj.CueColor=gray;
settings.stimObj.CueList={'<<<', '>>>', '???'};
% Memorized stim
settings.stimObj.StimSize_Deg=0.3; % degrees of VISUAL angle
settings.stimObj.StimColor=gray;
settings.stimObj.StimToCenterRadius_Deg=4; % degrees of VISUAL angle
settings.stimObj.StimJitterRadius_Deg=0.5; % degrees of VISUAL angle
settings.stimObj.StimToCenterAngles=deg2rad([125, 145, 215, 235, 305, 325, 35, 55]); % RADIAL coordinates
% Distracter
settings.stimObj.DistColor=settings.stimObj.StimColor;
% settings.stimObj.DistSize_Deg=settings.stimObj.StimSize_Deg; % degrees of VISUAL angle
settings.stimObj.DistSize_Deg=0.25; % degrees of VISUAL angle
settings.stimObj.DistSpread=0.6; % radius of the cluster, in degrees of VISUAL angle
settings.stimObj.DistAngles=deg2rad([-15 0 15]); % RADIAL coordinates
settings.stimObj.DistAngles_Jitter=deg2rad(3); % RADIAL coordinates
% Create some colors in CIE-Lch space
Lightness=45;
Chroma=100;
Hue=[140; 320]; % green and purple
StimColorsLch = [...
    Lightness Chroma Hue(1); ...
    Lightness Chroma Hue(2); ...
    ];
for i=1:length(Hue)
    StimColorsRGB(i,:) = min(max(colorspace('LCH->RGB',StimColorsLch(i,:)),0),1);
end
settings.stimObj.Colors=StimColorsRGB;


%% Set devices
% Keyboard (CONTROL DEVICE)
settings.key.Exit='e'; % key #8
settings.key.Go='space'; % key #44
settings.key.keyList=zeros(256,1); settings.key.keyList(8)=1;
    
end % function