% Collect initial user inputs
function settings=GetInputs(settings)

%Set subject number and distance
if settings.generalData.DebugMode
    fprintf(['\n\nRunning in debug mode. NOT appropriate if this is not a test!' ...
        '\nWill set subject number and distance automatically. Press any key to continue...\n\n']);
    KbReleaseWait; KbWait(-1); KbReleaseWait;
    settings.generalData.SubjectID=99;
    settings.screenValues.observerDistanceInch=22.5;
else
    settings.generalData.SubjectID=[];
    while isempty(settings.generalData.SubjectID)
        settings.generalData.SubjectID=input('\nEnter subject number [use numbers only]\n: ');
    end
    settings.screenValues.observerDistanceInch=0;
    while settings.screenValues.observerDistanceInch ~= 22.5
        fprintf('\n\nNOTE: screen-to-subjectEyes distance MUST BE 22.5 inches.');
        settings.screenValues.observerDistanceInch=input('\nEnter screen-to-subjectEyes distance in inches [use numbers only]\n: ');
    end
end
settings.screenValues.observerDistanceCM=settings.screenValues.observerDistanceInch*2.54;

% Set devices
settings.generalData.ControlDeviceIndex = input_device_by_prompt('\n\nPlease press any key on the CONTROL device:\n');
fprintf('\nControl device chosen!\n\n');
settings.generalData.ResponseDeviceIndex = input_device_by_prompt('\n\nPlease press any key on the RESPONSE device:\n');
fprintf('\nResponse device chosen!\n\n');

end % function