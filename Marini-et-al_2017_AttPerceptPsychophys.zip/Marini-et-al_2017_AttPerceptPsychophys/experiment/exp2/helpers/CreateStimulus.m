function CreateStimulus(argument,settings,trial,ExpTable)

% Values for argument:
% 'stim', 'cue'

tableIndexes=LoadTableIndexes;

% Shortcuts
current_trial_index=trial.index;
XCenter=settings.screenValues.XCenter;
YCenter=settings.screenValues.YCenter;
windowPtr=settings.screenValues.windowPtr;

% StimObj data
CueColor=settings.stimObj.CueColor;
CueText=settings.stimObj.CueList{ExpTable(current_trial_index,tableIndexes.CueDirection)};
StimPos_XY=[ExpTable(current_trial_index,tableIndexes.StimPosX), ExpTable(current_trial_index,tableIndexes.StimPosY)];
UnattendedStimPos_XY=[ExpTable(current_trial_index,tableIndexes.UnattStimPosX), ExpTable(current_trial_index,tableIndexes.UnattStimPosY)];
StimColor=settings.stimObj.StimColor;
StimColor=[255 0 0];
StimSize_Pix=settings.stimObj.StimSize_Pix;


%% Draw
switch argument
    case 'stim'
        Screen('DrawDots', windowPtr, StimPos_XY, StimSize_Pix, StimColor, [], 2);
        Screen('DrawDots', windowPtr, UnattendedStimPos_XY, StimSize_Pix, StimColor, [], 2);
    case 'cue'
        TextBounds = fix(Screen(windowPtr, 'TextBounds', char(CueText))/2);
        Screen('DrawText', windowPtr, CueText , XCenter-TextBounds(3), YCenter, CueColor);
end


end % function

