function trial=DelayPeriod(settings,trial,ExpTable)

elapsed_time=GetSecs-trial.timepoint2;
ppd=settings.screenValues.PixelPerDegree;

tableIndexes=LoadTableIndexes;

switch trial.type
    case 0
        trial.timepoint5=GetSecs;
        % Wait delay
        maximum_time=settings.duration.Delay;
        while elapsed_time < maximum_time-settings.screenValues.FlipInterval*0.5
            elapsed_time=GetSecs-trial.timepoint2;
        end
        trial.timepoint6=GetSecs;
        
    case 1
        
        % fprintf('DIST delay')
        % Prepare coords of random dots
        dist_elem_size_pix=settings.stimObj.DistSize_Pix;
        DistCenterOfMass_XY=[ExpTable(trial.index,tableIndexes.DistCoMassX), ExpTable(trial.index,tableIndexes.DistCoMassY)];
        DistSpread_Deg=settings.stimObj.DistSpread;
        DistSpread_Pix=DistSpread_Deg*ppd;
        UnattDistCenterOfMass_XY=[ExpTable(trial.index,tableIndexes.UnattDistCoMassX), ExpTable(trial.index,tableIndexes.UnattDistCoMassY)];
        UnattDistSpread_Deg=settings.stimObj.DistSpread;
        UnattDistSpread_Pix=UnattDistSpread_Deg*ppd;
        
        % Pick distracter angle random
        angles=([45:90:360; 30:90:360; 60:90:360; 90:90:360; 22.5:90:360; 67.5:90:360]);
        randar=[];
        randar(1,:)=angles(randsample(1:6,1),:);
        randar(2,:)=randar(1,:)+45;
        randar=deg2rad(randar);
        
        % Create coords of the distracter dots
        dist_elems = horzcat( ...
            [DistCenterOfMass_XY(1); DistCenterOfMass_XY(2)], ...
            [DistCenterOfMass_XY(1)+DistSpread_Pix/2*cos(randar(1,1:4)); DistCenterOfMass_XY(2)+DistSpread_Pix/2*sin(randar(1,1:4))], ...
            [DistCenterOfMass_XY(1)+DistSpread_Pix*cos(randar(2,1:4)); DistCenterOfMass_XY(2)+DistSpread_Pix*sin(randar(2,1:4))]);
        
        unatt_dist_elems = horzcat( ...
            [UnattDistCenterOfMass_XY(1); UnattDistCenterOfMass_XY(2)], ...
            [UnattDistCenterOfMass_XY(1)+UnattDistSpread_Pix/2*cos(randar(1,1:4)); UnattDistCenterOfMass_XY(2)+UnattDistSpread_Pix/2*sin(randar(1,1:4))], ...
            [UnattDistCenterOfMass_XY(1)+UnattDistSpread_Pix*cos(randar(2,1:4)); UnattDistCenterOfMass_XY(2)+UnattDistSpread_Pix*sin(randar(2,1:4))]);
        
        % Color
        dist_color=repmat(transpose(settings.stimObj.DistColor),1,size(dist_elems,2));
      
        % Draw, not show
        Screen('DrawDots', settings.screenValues.windowPtr, dist_elems, dist_elem_size_pix, dist_color, [], 2);
        Screen('DrawDots', settings.screenValues.windowPtr, unatt_dist_elems, dist_elem_size_pix, dist_color, [], 2);
        DrawMyFixation(settings,'dot');
        
        % Wait before presenting dist
        elapsed_time=GetSecs-trial.timepoint4;
        while elapsed_time < settings.duration.StimToDist-settings.screenValues.FlipInterval*0.5
            elapsed_time=GetSecs-trial.timepoint4;
        end

        % Show
        eval(settings.screenValues.FlipCommand);
        trial.timepoint5=StimulusOnsetTime;
        elapsed_time=GetSecs-trial.timepoint5;
        
        % Dist presentation time
        while elapsed_time < settings.duration.Dist-settings.screenValues.FlipInterval*0.5       
            elapsed_time=GetSecs-trial.timepoint5;
        end
        
% UNCOMMENT FOR TIMING TEST        
% % %         if iteracs~=25 % to use with pluto % timing test
% % %             iteracs % timing test
% % %             numiteracsdiff=numiteracsdiff+1; % timing test
% % %         end  % timing test
% % % end %pluto % timing test
% % % PartialStimDuration=StimulusOnsetTime-trial.timepoint5;

        % Clear screen
        DrawMyFixation(settings,'dot');
        eval(settings.screenValues.FlipCommand);
        trial.timepoint6=StimulusOnsetTime;
        
% UNCOMMENT FOR TIMING TEST        
% % % StimDuration=trial.timepoint6-trial.timepoint5;
% % % fprintf('\nPartStimDuration %.3f StimDuration %.3f',PartialStimDuration,StimDuration);
            
        % Wait
        elapsed_time=GetSecs-trial.timepoint6;
        while elapsed_time < settings.duration.DistToProbe-settings.screenValues.FlipInterval*0.5
            elapsed_time=GetSecs-trial.timepoint6;
        end
        
end

end % function