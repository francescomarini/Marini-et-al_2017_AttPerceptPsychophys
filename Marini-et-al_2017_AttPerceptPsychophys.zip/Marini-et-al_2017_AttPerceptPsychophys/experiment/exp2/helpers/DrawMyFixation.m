% This function draws a fixation cross in the windowPtr
% Usage:
% []=DrawMyFixation(settings)
% The function does NOT flip the screen buffer.

function DrawMyFixation(settings,argument)

windowPtr=settings.screenValues.windowPtr;
X_Monitor_Center=settings.screenValues.XCenter;
Y_Monitor_Center=settings.screenValues.YCenter;
color=settings.screenValues.FixationColor;
size_pix=settings.screenValues.FixationSize_Pix;
updrift_pix=settings.screenValues.FixationUpdrift_Pix;
pen_width=settings.screenValues.FixationPenWidth_Pix;

switch argument
    
    case 'cross'
        Screen('DrawLine', windowPtr, color, X_Monitor_Center-size_pix, Y_Monitor_Center-updrift_pix, X_Monitor_Center+size_pix, Y_Monitor_Center-updrift_pix, pen_width);
        Screen('DrawLine', windowPtr, color, X_Monitor_Center, Y_Monitor_Center-size_pix-updrift_pix, X_Monitor_Center, Y_Monitor_Center+size_pix-updrift_pix, pen_width);
    case 'dot'
        Screen('DrawDots', windowPtr, [X_Monitor_Center,Y_Monitor_Center-updrift_pix], size_pix, color, [], 2);
    case 'square'
        Screen('DrawDots', windowPtr, [X_Monitor_Center,Y_Monitor_Center-updrift_pix], size_pix, color, [], 2);

end
        
end


