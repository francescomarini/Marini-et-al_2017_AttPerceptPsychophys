function settings=OpenScreen(settings, doFlip)

    % Initialize OpenGL
    AssertOpenGL;
    InitializeMatlabOpenGL;

    % Shortcuts
    DM=settings.generalData.DebugMode;
    WWD=settings.screenValues.Windowed;
    
    % Check we're loading the appropriate gamma correction file
    gcfile='GammaTable_Dell.mat';
    fprintf(['\nLoading gamma correction file: ',gcfile]);
    fprintf('\nIf the file is correct press any key, else terminate with Ctrl+C\n\n');
    KbWait(settings.generalData.ControlDeviceIndex);
    
    % Set screen preferences
    if DM
        skip_sync_tests=1;
        Screen('Preference','SkipSyncTests', skip_sync_tests);
        Screen('Preference', 'SuppressAllWarnings', 0);
        Screen('Preference','VisualDebugLevel', 1);
    else
        skip_sync_tests=0;
        maxStddev=0.002; minSamples=50; maxDeviation=0.2; maxDuration=5; % Parameters for synctests
        Screen('Preference','SyncTestSettings', maxStddev, minSamples, maxDeviation, maxDuration);
        Screen('Preference','SkipSyncTests', skip_sync_tests);
        Screen('Preference', 'SuppressAllWarnings', 0);
        Screen('Preference','VisualDebugLevel', 0);
        if skip_sync_tests
            warning('You are skipping sync tests but the script is not running in debug mode!')
            fprintf('\n[Read warning message above]\nThis will seriously affect timing. You should stop if this is an actual experiment.\nPress any key to confirm you read this message\n');
            KbReleaseWait; KbWait; KbReleaseWait;
        end
    end
    
    % Open a new on-screen window
    if ~WWD
        [settings.screenValues.windowPtr, settings.screenValues.ScreenSize]=Screen('OpenWindow',settings.screenValues.screenNumber,settings.screenValues.BackgroundColor);
    else  % if we're dubugging open a 640x480 window that is a little bit down from the upper left of the big screen
        [settings.screenValues.windowPtr, settings.screenValues.ScreenSize]=Screen('OpenWindow',settings.screenValues.screenNumber,settings.screenValues.BackgroundColor,[20,20,820,620],[],[],[],[],[],kPsychGUIWindow,[]);   
    end
     
    % Prioritize open screen window
    Priority(MaxPriority(settings.screenValues.windowPtr));
    
    % Retrieve some screen measures
    settings.screenValues.XDim_px=settings.screenValues.ScreenSize(3)-settings.screenValues.ScreenSize(1);
    settings.screenValues.YDim_px=settings.screenValues.ScreenSize(4)-settings.screenValues.ScreenSize(2);
    settings.screenValues.XCenter=settings.screenValues.XDim_px/2;
    settings.screenValues.YCenter=settings.screenValues.YDim_px/2;
    if ~DM && (settings.screenValues.XDim_px~=1024 || settings.screenValues.YDim_px~=768)
        sca;
        error('Screen resolution must be 1024 x 768 for this experiment');
    end
     
    % Retrieve screen dimensions in mm
    [settings.screenValues.XDim_mm, settings.screenValues.YDim_mm] = Screen('DisplaySize', settings.screenValues.screenNumber);
    settings.screenValues.XDim_cm = settings.screenValues.XDim_mm/10;
    settings.screenValues.YDim_cm = settings.screenValues.YDim_mm/10;
    
    % Convert existing measures from degrees of visual angle to pixels
    [settings.stimObj, settings.screenValues.PixelPerDegree] = deg2pix(settings.stimObj,settings);
    settings.screenValues.DegreePerPixel=1/settings.screenValues.PixelPerDegree;
    
    % Autodetect flip interval
    settings.screenValues.FlipInterval=Screen('GetFlipInterval',settings.screenValues.windowPtr);

    % Prepare flip command;
    settings.screenValues.FlipCommand=['[vbl, StimulusOnsetTime] = Screen(' char(39) 'Flip' char(39) ',settings.screenValues.windowPtr,[], [], []);'];
    settings.screenValues.FlipCommandDNC=['[vbl, StimulusOnsetTime] = Screen(' char(39) 'Flip' char(39) ',settings.screenValues.windowPtr,[], [1], []);'];
    
    % Gamma correction
    BackupCluts();
    load(gcfile); settings.screenValues.gammaTable=gammaTable;
    settings.screenValues.oldGamma = Screen('ReadNormalizedGammaTable', settings.screenValues.windowPtr);
    Screen('LoadNormalizedGammaTable', settings.screenValues.windowPtr, settings.screenValues.gammaTable*[1,1,1]);
    
    % Blend function (required for anti-aliasing while drawing dots)
    sourceFactorNew = GL_SRC_ALPHA;
    destinationFactorNew = GL_ONE_MINUS_SRC_ALPHA;
    Screen('BlendFunction', settings.screenValues.windowPtr, sourceFactorNew, destinationFactorNew);
    
    % Hide mouse
    if ~DM
        HideCursor;
        commandwindow;
    end
    
    % If requested, perform initial flip
    if doFlip
        eval(settings.screenValues.FlipCommand);
    end
    
end



%% deg2pix (HELPER FUNCTION)
function [structure, ppd] = deg2pix(structure,settings)

% converts degrees visual angle to pixel units before rendering
% with PTB.
% js - 10.2007

% Converts all fields of structure with string Deg in their name to Pix
% and creates ppd (Pixel Per Degree)
% edited by FM 08.2015

% figure out pixels per degree, settings.screenValues.ScreenSize(1) is x coord for upper left of
% screen, and settings.screenValues.ScreenSize(3) is x coord for lower right corner of screen 
ppd = pi*settings.screenValues.XDim_px / atan(settings.screenValues.XDim_cm/settings.screenValues.observerDistanceCM/2) / 360; 

% get name of each field in p
s = fieldnames(structure);

% convert all fields with the word 'Deg' from degrees visual angle to
% pixels, then store in a renamed field name
for i=1:length(s)
    ind = strfind(s{i}, 'Deg');
    if ind
        curVal = getfield(structure,s{i});
        tmp = char(s{i});
        newfn = [tmp(1:ind-1), 'Pix'];
        structure = setfield(structure,newfn,curVal*ppd);
    end
end

end % function