function [tableIndexes, tableNames, settings]=LoadTableIndexes(settings)

%% Indexes of columns within experiment_table

tableIndexes={};

tableIndexes.SubjectID=1;
tableIndexes.BlockNumber=2;
tableIndexes.OrderedTrialNumber=3;
tableIndexes.RandomTrialNumber=4;
tableIndexes.Distraction=5; % 0=no-distracter 1=distracter

tableIndexes.StimAngle=6;
tableIndexes.StimEcc_Pix=7;
tableIndexes.StimPosX=8;
tableIndexes.StimPosY=9;

tableIndexes.UnattStimAngle=10;
tableIndexes.UnattStimEcc_Pix=11;
tableIndexes.UnattStimPosX=12;
tableIndexes.UnattStimPosY=13;

tableIndexes.DistCoMassAngle=14;
tableIndexes.DistCoMassEcc_Pix=15;
tableIndexes.DistCoMassX=16;
tableIndexes.DistCoMassY=17;

tableIndexes.UnattDistCoMassAngle=18;
tableIndexes.UnattDistCoMassEcc_Pix=19;
tableIndexes.UnattDistCoMassX=20;
tableIndexes.UnattDistCoMassY=21;

tableIndexes.ResponseAngle=22;
tableIndexes.ResponseEcc=23;
tableIndexes.ResponseX=24;
tableIndexes.ResponseY=25;
tableIndexes.ResponseTime=26;

tableIndexes.CueDirection=27;
tableIndexes.ITI=28;

tableIndexes.timepoint0=30;
tableIndexes.timepoint1=31;
tableIndexes.timepoint2=32;
tableIndexes.timepoint3=33;
tableIndexes.timepoint4=34;
tableIndexes.timepoint5=35;
tableIndexes.timepoint6=36;
tableIndexes.timepoint7=37;
tableIndexes.timepoint8=38;
tableIndexes.timepoint9=39;
tableIndexes.timepoint10=40;

tableNames=fieldnames(tableIndexes);

settings.generalData.numColumns=size(fieldnames(tableIndexes),1);

end