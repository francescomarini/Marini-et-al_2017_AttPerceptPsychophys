function [practice_exp_table, exp_table]=CreateExperimentTable(settings,runmode)

fprintf('\n\nCreating experiment table...');
if strcmp(runmode,'behavior')
    fprintf(' Mode: BEHAVIOR\n\n');
elseif strcmp(runmode,'eeg')
    fprintf(' Mode: EEG\n\n');
end

% Load table index
tableIndexes=LoadTableIndexes(settings);
numColumns=settings.generalData.numColumns;

%% Shortcuts
% General
numPracticeTrials=settings.generalData.numPracticeTrials;
numBlocks=settings.generalData.numBlocks;
numTrialsPerBlock=settings.generalData.numTrialsPerBlock;
numTrials=settings.generalData.numTrials;
screenValues=settings.screenValues;
XCenter=screenValues.XCenter;
YCenter=screenValues.YCenter;
ppd=screenValues.PixelPerDegree;
% Stim
StimToCenterRadius_Pix=settings.stimObj.StimToCenterRadius_Pix;
StimJitterRadius_Deg=settings.stimObj.StimJitterRadius_Deg;
StimToCenterAngles=settings.stimObj.StimToCenterAngles;
% Distractor
DistCOMangles=settings.stimObj.DistAngles;
DistCOMangles_Jitter=settings.stimObj.DistAngles_Jitter;


%% Create all spatial positions for stimuli
tmp_stimangles=transpose([combvec(StimToCenterAngles(1:4),StimToCenterAngles(5:8)), ...
    combvec(StimToCenterAngles(5:8),StimToCenterAngles(1:4))]); % in radians
all_stimangles=repmat(tmp_stimangles,numTrials/length(tmp_stimangles),1); % in radians
all_distpresence=[zeros(numTrials/4,1); ones(3*numTrials/4,1)];
all_distangle=[nan(numTrials/4,1); ...
    transpose(linspace(DistCOMangles(1)-DistCOMangles_Jitter, DistCOMangles(1)+DistCOMangles_Jitter, numTrials/4)); ...
    transpose(linspace(DistCOMangles(2)-DistCOMangles_Jitter, DistCOMangles(2)+DistCOMangles_Jitter, numTrials/4));
    transpose(linspace(DistCOMangles(3)-DistCOMangles_Jitter, DistCOMangles(3)+DistCOMangles_Jitter, numTrials/4))];
all_stimjitters_angle=Shuffle(linspace(-1*(2*pi*((ppd*StimJitterRadius_Deg)/(2*pi*StimToCenterRadius_Pix))), ...
    (2*pi*((ppd*StimJitterRadius_Deg)/(2*pi*StimToCenterRadius_Pix))), numTrials)); % in radians
all_stimjitters_ecc=Shuffle(linspace(-StimJitterRadius_Deg*ppd, StimJitterRadius_Deg*ppd, numTrials)); % in pixels


%% Create exp_table
exp_table=zeros(numTrials,numColumns);

for triali=1:numTrials

    % Get stim data
    stimpos_jitter_ecc_pix=all_stimjitters_ecc(triali); % jitter for eccentricity
    stimpos_jitter_angle=all_stimjitters_angle(triali); % jitter for angle
    stimangle=all_stimangles(triali,1)+stimpos_jitter_angle; % actual stim angle
    unattstimangle=all_stimangles(triali,2)+stimpos_jitter_angle; % actual unattended stim angle
    stimecc_pix=StimToCenterRadius_Pix+stimpos_jitter_ecc_pix; % actual eccentricity
    distangle=all_distangle(triali); % actual distracter jitter
    
    % Stim
    exp_table(triali,tableIndexes.StimAngle)=stimangle;
    exp_table(triali,tableIndexes.StimEcc_Pix)=stimecc_pix;
    [exp_table(triali,tableIndexes.StimPosX), exp_table(triali,tableIndexes.StimPosY)]=pol2xy(stimangle, stimecc_pix/ppd, XCenter, YCenter, ppd);

    % Unattended stim
    exp_table(triali,tableIndexes.UnattStimAngle)=unattstimangle;
    exp_table(triali,tableIndexes.UnattStimEcc_Pix)=stimecc_pix; % note that unattended stim has the same eccentricity
    [exp_table(triali,tableIndexes.UnattStimPosX), exp_table(triali,tableIndexes.UnattStimPosY)]=pol2xy(unattstimangle, stimecc_pix/ppd, XCenter, YCenter, ppd);

    % Dist
    exp_table(triali,tableIndexes.Distraction)=all_distpresence(triali);
    exp_table(triali,tableIndexes.DistCoMassAngle)=stimangle+distangle;
    exp_table(triali,tableIndexes.DistCoMassEcc_Pix)=stimecc_pix; % note that distracter stim has the same eccentricity
    [exp_table(triali,tableIndexes.DistCoMassX), exp_table(triali,tableIndexes.DistCoMassY)]=pol2xy(stimangle+distangle, stimecc_pix/ppd, XCenter, YCenter, ppd);
    
    % Unattended dist
    exp_table(triali,tableIndexes.UnattDistCoMassAngle)=unattstimangle+distangle; % note that unattended dist has the same jitter as dist
    exp_table(triali,tableIndexes.UnattDistCoMassEcc_Pix)=stimecc_pix; % note that distracter stim has the same eccentricity
    [exp_table(triali,tableIndexes.UnattDistCoMassX), exp_table(triali,tableIndexes.UnattDistCoMassY)]=pol2xy(unattstimangle+distangle, stimecc_pix/ppd, XCenter, YCenter, ppd);
    
    % Cue
    if stimangle>deg2rad(90) && stimangle<deg2rad(270); cueindex=1;
    elseif stimangle<deg2rad(90) || stimangle>deg2rad(270); cueindex=2;
    else cueindex=3; end
    exp_table(triali,tableIndexes.CueDirection)=cueindex;

end

% ITI
exp_table(:,tableIndexes.ITI)=transpose(Shuffle(linspace(settings.duration.ITI(1), settings.duration.ITI(2), numTrials)));

% Random sequence
sequence_exp=Shuffle(1:numTrials);
indexes_Dtrials=Shuffle(sequence_exp(1:length(sequence_exp)/4*3));
indexes_Ntrials=Shuffle(sequence_exp(length(sequence_exp)/4*3+1:end));
exp_table(exp_table(:,tableIndexes.Distraction)==1,tableIndexes.RandomTrialNumber)=indexes_Dtrials;
exp_table(exp_table(:,tableIndexes.Distraction)==0,tableIndexes.RandomTrialNumber)=indexes_Ntrials;

% Practice
practice_exp_table_p1=exp_table(randsample(find(exp_table(:,tableIndexes.Distraction)==1),numPracticeTrials/4*3),:);
practice_experiment_table_p2=exp_table(randsample(find(exp_table(:,tableIndexes.Distraction)==0),numPracticeTrials/4),:);
practice_exp_table=[practice_exp_table_p1; practice_experiment_table_p2];
sequence_practice=Shuffle(1:numPracticeTrials);
practice_exp_table(:,tableIndexes.RandomTrialNumber)=sequence_practice;

% Block number
for blocki=1:numBlocks
    indexes_current_block=transpose((1+(blocki-1)*numTrialsPerBlock):(blocki*numTrialsPerBlock));
    exp_table(ismember(exp_table(:,tableIndexes.RandomTrialNumber),indexes_current_block),tableIndexes.BlockNumber)=blocki;
end

% Subject number
exp_table(:,tableIndexes.SubjectID)=settings.generalData.SubjectID;


fprintf('\nExperiment table READY\n');

end % function

