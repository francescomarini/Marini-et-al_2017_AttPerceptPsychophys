function outputFiles=PrepareOutputFiles(settings)

% Shortcuts
path=settings.path;
generalData=settings.generalData;
datafolder=path.Data;

% Set up files and folders for saving data
current_date=num2str(yyyymmdd(datetime('now','ConvertFrom','yyyymmdd')));
current_time=datestr(now,'HHMM');
if generalData.SubjectID<=9
% % %     current_subject_datafile_txt=fullfile(datafolder,['Subj0' num2str(generalData.SubjectID) '_' current_date '_' current_time '.txt']);
    current_subject_workspace_filename=fullfile(datafolder,['wrksp_Subj0' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
    current_subject_trials_filename=fullfile(datafolder,['trials_Subj0' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
    current_subject_exptable_filename=fullfile(datafolder,['ExpTable_Subj0' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
else
% % %     current_subject_datafile_txt=fullfile(datafolder,['Subj' num2str(generalData.SubjectID) '_' current_date '_' current_time '.txt']);
    current_subject_workspace_filename=fullfile(datafolder,['wrksp_Subj' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
    current_subject_trials_filename=fullfile(datafolder,['trials_Subj' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
    current_subject_exptable_filename=fullfile(datafolder,['ExpTable_Subj' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
end
if ~exist( datafolder,'dir'); mkdir( datafolder); end

outputFiles.datafileWrkspFilename=current_subject_workspace_filename;
outputFiles.datafileTrialsFilename=current_subject_trials_filename;
outputFiles.datafileExpTableFilename=current_subject_exptable_filename;

end