%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SHIELD 08 EXPERIMENT                       %
%                                            %
% Script developed by:                       %
% Francesco Marini, PhD                      %
% University of California San Diego         %
% e-mail: fmarini@ucsd.edu                   %
%                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% INFO/HELP
% Use: SHIELD08_Run(runmode)
% This function runs the SHIELD08 paradigm.
% Argument "runmode" must be specified as a string.
% Allowed arguments: 'behavior', 'eeg'
% Example: SHIELD08_Run('behavior')

function SHIELD08_Run(runmode)

clearvars -except runmode

% Set up restarting
if strcmp(runmode,'restart')
    try
        restart_datafolder=fullfile(fileparts(fileparts(which('SHIELD08_Run'))),'data');
        fprintf('\nOpen the most recent workspace file for this subject (filename starts with wrksp):\n');
        [filn,filp] = uigetfile(fullfile(restart_datafolder,'*.mat'),'Open the most recent workspace file for this subject... (filename starts with wrksp)');
        load(fullfile(filp,filn));
        fprintf(['\nFile loaded successfully!\n\nReady to restart subject ', num2str(settings.generalData.SubjectID), ' on trial ', num2str(trial.counter), '\n']);
        clearvars restart_*
    catch
        fprintf('\nUnable to restart :(\n');
    end
    sessions={'experiment'};
else
    fprintf('\nDo you want to do practice? (y/n, leave blank=yes):');
    KbReleaseWait;
    do_practice=input(' ','s');
    if strcmpi(do_practice,'n')
        sessions={'experiment'};
    elseif isempty(do_practice) || strcmp(do_practice,'y')
        sessions={'practice', 'experiment'};
    end
end


%% Initializations %%
PsychDefaultSetup(1); % Basic setup of PTB: AssertOpenGL and UnifyKbNames
jheapcl; % Clean Java buffer
rng('shuffle', 'twister'); % Initialize random number generator
commandwindow; % Move the focus to the command window
initial_time=GetSecs;

% Load initial values
if ~strcmp(runmode,'restart')
    settings=SHIELD08_Initialize(runmode);
end

% Load table indexes
[tableIndexes, ~, settings]=LoadTableIndexes(settings);

% Initialize screen and open onscreen window
settings=OpenScreen(settings, 1);

% Prepare output files
settings.outputFiles=PrepareOutputFiles(settings);

% Create experiment table
if ~strcmp(runmode,'restart')
    [exptable.practice, exptable.experiment] = CreateExperimentTable(settings,runmode);
end

% Preload functions
GetSecs;WaitSecs(0.1);KbCheck(settings.generalData.ResponseDeviceIndex);KbCheck(settings.generalData.ControlDeviceIndex);KbReleaseWait;
if ~IsWin; KbQueueCreate(settings.generalData.ControlDeviceIndex, settings.key.keyList); end
exiting=0;

%% Display welcome screen
if ~strcmp(runmode,'restart') && strcmp(sessions{1},'practice')
    DisplayOnscreenMessage(settings,'instructions',1,1);
    Countdown(settings.screenValues.windowPtr,3);
elseif strcmp(runmode,'restart')
    DisplayOnscreenMessage(settings,'restart',1,1);
    Countdown(settings.screenValues.windowPtr,5);
end

% Draw fixation
DrawMyFixation(settings,'dot');
% Show fixation
eval(settings.screenValues.FlipCommand);
WaitSecs(1);

%% Practice/Experiment loop
for sessioni=1:length(sessions)
       
    if ~strcmp(runmode,'restart')
        % Setup session type, load exp_table, figure out num trials
        if strcmp(sessions{sessioni},'practice')
            experiment_table=exptable.practice;
            is_practice=1;
            numTrials=settings.generalData.numPracticeTrials;
        elseif strcmp(sessions{sessioni},'experiment')
            experiment_table=exptable.experiment;
            is_practice=0;
            numTrials=settings.generalData.numTrials;
        end
        % Initialize performance metrics and counters
        trial.blocktrialcounter=0; trial.startfrom=1; trial.blockcounter=1;
    else
        % Manage some variables if restarting
        trial.startfrom=trial.counter-1;
        trial.blocktrialcounter=trial.blocktrialcounter-1;
        numTrials=settings.generalData.numTrials;
        is_practice=0;
    end
    
    % Start monitoring presses of the exit key
    if ~IsWin
        KbQueueStart(settings.generalData.ControlDeviceIndex);
    end
    
    %% Trial loop
    
    %ListenChar(2); % Turn off the output to the command window
    triali = trial.startfrom;

    while triali <= numTrials
        
%          try
            
            % Update counters
            trial.counter=triali;
            trial.blocktrialcounter=trial.blocktrialcounter+1;
            % Figure out trial type
            trial.index=find(experiment_table(:,tableIndexes.RandomTrialNumber)==trial.counter);
            trial.type=experiment_table(trial.index,tableIndexes.Distraction);
            % Stim position
            trial.StimPos_XY = [experiment_table(trial.index,tableIndexes.StimPosX), experiment_table(trial.index,tableIndexes.StimPosX)];
            trial.StimPos_Pol = xy2pol(trial.StimPos_XY, settings.screenValues.XCenter, settings.screenValues.YCenter, settings.screenValues.PixelPerDegree);
                               
            % Check if is time for a break. If so, do it!
            %ListenChar(0); % Turn on keyboard input
            if ~is_practice && trial.counter==1 % First trial of experiment
                DisplayOnscreenMessage(settings,'ready',1,1); % Ready to start
                if ~settings.generalData.quickMode; Countdown(settings.screenValues.windowPtr,5); end % Count down
                DrawMyFixation(settings,'dot');
                eval(settings.screenValues.FlipCommand);
                WaitSecs(1);     
            elseif trial.counter~=1 && ismember(trial.counter,settings.generalData.PauseBeforeTrial) % Break
                jheapcl; % Clean up Java buffer
                DisplayOnscreenMessage(settings,'pause',1,1,experiment_table(trial.index,tableIndexes.BlockNumber)-1); % Display message
                trial.blocktrialcounter=1; trial.blockcounter=trial.blockcounter+1; % Adjust counters
                if ~settings.generalData.quickMode; Countdown(settings.screenValues.windowPtr,3); end % Count down
                DrawMyFixation(settings,'dot');
                eval(settings.screenValues.FlipCommand);
                WaitSecs(1);  
            end
            %ListenChar(2); % Turn off keyboard
                        
            % Draw and show fixation
            DrawMyFixation(settings,'dot');
            eval(settings.screenValues.FlipCommand);
            trial.timepoint0=StimulusOnsetTime; % ITI begins
            
            % Wait for ITI
            elapsed_time=GetSecs-trial.timepoint0;
            while elapsed_time < experiment_table(trial.index,tableIndexes.ITI)-settings.screenValues.FlipInterval*0.5
                elapsed_time=GetSecs-trial.timepoint0;
            end
            
            % Draw cue and fixation
            CreateStimulus('cue',settings,trial,experiment_table);
            DrawMyFixation(settings,'dot');
            eval(settings.screenValues.FlipCommand);
            trial.timepoint1=StimulusOnsetTime; %cue onset
            elapsed_time=GetSecs-trial.timepoint1;
            
            % Cue presentation time
            while elapsed_time < settings.duration.Cue-settings.screenValues.FlipInterval*0.5
                elapsed_time=GetSecs-trial.timepoint1;
            end
            
            % Clear screen
            DrawMyFixation(settings,'dot');
            eval(settings.screenValues.FlipCommand);
            trial.timepoint2=StimulusOnsetTime; %cue offset
            
            % Prepare Stim and fixation but don't show yet
            CreateStimulus('stim',settings,trial,experiment_table);
            DrawMyFixation(settings,'dot');
            
            % Cue-Stim delay
            elapsed_time=GetSecs-trial.timepoint2;
            while elapsed_time < settings.duration.CueToStim-settings.screenValues.FlipInterval*0.5
                elapsed_time=GetSecs-trial.timepoint2;
            end
            
            % Stimulus onset
            eval(settings.screenValues.FlipCommand);
            trial.timepoint3=StimulusOnsetTime; % stim onset
            elapsed_time=GetSecs-trial.timepoint3;
            
            % Prepare for clearing screen
            DrawMyFixation(settings,'dot');
            
            % Stim presentation time
            while elapsed_time < settings.duration.Stimulus-settings.screenValues.FlipInterval*0.5
                elapsed_time=GetSecs-trial.timepoint3;
            end
            eval(settings.screenValues.FlipCommand);
            trial.timepoint4=StimulusOnsetTime; % stim offset = clear screen (no mask)
                        
            % Delay period
            trial=DelayPeriod(settings,trial,experiment_table);
                      
            % Show response screen
            SetMouse(settings.screenValues.XCenter, settings.screenValues.YCenter, settings.screenValues.windowPtr);
            ShowCursor('CrossHair',settings.screenValues.screenNumber);
            trial.timepoint7=GetSecs; % resp onset start for RT
            
            % Wait for response
            [~,~,buttons] = GetMouse;
            while any(buttons); [~,~,buttons] = GetMouse; end % if already down, wait for release
            while ~any(buttons); [x,y,buttons] = GetMouse; end % wait for press
            trial.timepoint8=GetSecs; % response time
            HideCursor;
            [~,~,buttons] = GetMouse;
            while any(buttons); [~,~,buttons] = GetMouse; end % wait for release
            trial.response_XY=[x, y];
            trial.response_Pol = xy2pol(trial.response_XY, settings.screenValues.XCenter, settings.screenValues.YCenter, settings.screenValues.PixelPerDegree);
            trial.rt=trial.timepoint8-trial.timepoint7;
            trial.timepoint9=GetSecs;

            % Display trial data
            fprintf('\nTrial %.0f',trial.counter); fprintf(' RT=%.3f',trial.rt); fprintf(' X=%.2f Y=%.2f ',trial.response_XY(1),trial.response_XY(2)); % Print performance on screen
            % Log data
            experiment_table(trial.index,tableIndexes.ResponseTime)=trial.rt;
            experiment_table(trial.index,tableIndexes.ResponseX)=trial.response_XY(1);         experiment_table(trial.index,tableIndexes.ResponseY)=trial.response_XY(2);
            experiment_table(trial.index,tableIndexes.ResponseAngle)=trial.response_Pol(1);    experiment_table(trial.index,tableIndexes.ResponseEcc)=trial.response_Pol(2);
            
            experiment_table(trial.index,tableIndexes.timepoint0)=trial.timepoint0;            experiment_table(trial.index,tableIndexes.timepoint1)=trial.timepoint1; 
            experiment_table(trial.index,tableIndexes.timepoint2)=trial.timepoint2;            experiment_table(trial.index,tableIndexes.timepoint3)=trial.timepoint3;
            experiment_table(trial.index,tableIndexes.timepoint4)=trial.timepoint4;            experiment_table(trial.index,tableIndexes.timepoint5)=trial.timepoint5;
            experiment_table(trial.index,tableIndexes.timepoint6)=trial.timepoint6;            experiment_table(trial.index,tableIndexes.timepoint7)=trial.timepoint7; 
            experiment_table(trial.index,tableIndexes.timepoint8)=trial.timepoint8;            experiment_table(trial.index,tableIndexes.timepoint9)=trial.timepoint9;
            
            % If not practice save data in trialstruct
            if ~is_practice
                trialstruct(trial.counter)=trial;
            end
            
            % Update trial counter
            triali=triali+1;
            
            % Check on the exit key
            if ~IsWin && KbQueueCheck(settings.generalData.ControlDeviceIndex)
                exiting=1;
                break;
            end
            
            
%          catch
%              error_count=error_count+1;
%              fprintf('\nError on Trial %2.0f',trial.counter);
%              if error_count>=1
%                  if ~is_practice
%                      % Save output files
%                      save(settings.outputFiles.datafileWrkspFilename);
%                      save(settings.outputFiles.datafileTrialsFilename,'trialstruct');
%                      save(settings.outputFiles.datafileExpTableFilename,'experiment_table');
%                      %ListenChar(0);
%                  end
%                  error('An error occurred and the experiment was interrupted. Please try to restart.');
%              end
%          end
        
    end % end trial loop
       
end % end practice-experiment loop

%ListenChar(0); % Turn on the output to the command window

% Save output files
if ~is_practice
       save(settings.outputFiles.datafileWrkspFilename); % Save workspace
       save(settings.outputFiles.datafileTrialsFilename,'trialstruct'); % Save trials structure
       save(settings.outputFiles.datafileExpTableFilename,'experiment_table'); % Save exp table
    if ~exiting
        % End of experiment
        DisplayOnscreenMessage(settings,'goodbye',1,1);
    end
end

% Close screen and files
RestoreCluts;
Screen('CloseAll');
ShowCursor; % Show mouse arrow

% Time
total_time=GetSecs-initial_time;
fprintf('\n\nRunning time: %.0f minutes and %.0f seconds\n',floor(total_time/60),mod(total_time,60));

end

