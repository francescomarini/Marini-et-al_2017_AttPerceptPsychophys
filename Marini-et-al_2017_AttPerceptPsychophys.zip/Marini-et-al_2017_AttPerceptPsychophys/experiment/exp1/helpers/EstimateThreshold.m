function EstimateThreshold(UD,settings)

target_performance=settings.stimObj.THRtargetPerformance;
exclude_first_reversals=settings.stimObj.THRestWithoutFirstRev;

try
    
    %Threshold estimate as mean of all but the first three reversal points
    ThrDistance_Deg_Mean = PAL_AMUD_analyzeUD(UD, 'reversals', max(UD.reversal)-exclude_first_reversals);
    message = sprintf('\rThreshold estimate as mean of all but first %.0f reversals',exclude_first_reversals);
    message = strcat(message,sprintf(' reversals: %6.4f', ThrDistance_Deg_Mean));
    disp(message);
    
    %Threshold estimate found by fitting Gumbel
    params = PAL_PFML_Fit(UD.x, UD.response, ones(1,length(UD.x)), ...
        [0 50 .5 .01], [1 0 0 0], @PAL_Gumbel);
    ThrDistance_Deg_Gumbel=params(1);
    message = sprintf('Threshold estimate as alpha of fitted Gumbel: %6.4f'...
        , ThrDistance_Deg_Gumbel);
    disp(message);
    
    %Create simple plot:
    t = 1:length(UD.x);
    figure('name','Up/Down Adaptive Procedure');
    plot(t,UD.x,'k');
    hold on;
    plot(t(UD.response == 1),UD.x(UD.response == 1),'ko', 'MarkerFaceColor','k');
    plot(t(UD.response == 0),UD.x(UD.response == 0),'ko', 'MarkerFaceColor','w');
    set(gca,'FontSize',16);
    axis([0 max(t)+1 min(UD.x)-(max(UD.x)-min(UD.x))/10 max(UD.x)+(max(UD.x)-min(UD.x))/10]);
    line([1 length(UD.x)], [ThrDistance_Deg_Mean ThrDistance_Deg_Mean],'linewidth', 2, 'linestyle', '--', 'color','k');
    xlabel('Trial');
    ylabel('Stimulus Intensity');
    
    % Results
    fprintf('\n\nRESULTS')
    fprintf('\nTarget performance: %.2f',target_performance);
    fprintf('\nExact threshold distance estimate (Mean method, DEFAULT): %.4f', ThrDistance_Deg_Mean);
    fprintf('\nExact threshold distance estimate (Gumbel method): %.4f\n', ThrDistance_Deg_Gumbel);
    if ThrDistance_Deg_Mean<settings.stimObj.THRxMin
        fprintf('\nWARNING: The estimated threshold distance is too small! If you do not change it in the next step, it will be automatically set to the minimum allowed.\n');
    elseif ThrDistance_Deg_Mean>settings.stimObj.THRxMax
        fprintf('\nWARNING: The estimated threshold distance is larger than the upper tested limit! This is infrequent but may be OK...\nA visual inspection of the threshold graph is recommended\n');
    end
        resp='';
    while ~strcmpi(resp,'y') && ~strcmpi(resp,'n')
        resp=input('[NOTE: If you choose not to accept, you will be able to enter a different value]\nAccept threshold distance (DEFAULT)? [y/n] : ','s');
        if strcmpi(resp,'y')
            ThrDistance_Deg=ThrDistance_Deg_Mean;
        elseif strcmpi(resp,'n')
            ThrDistance_Deg=input(['\nENTER DESIRED THRESHOLD DISTANCE VALUE IN DEGREES OF VISUAL ANGLE (tested limits are min ',num2str(min(StimLevels)),' max ',num2str(max(StimLevels)),'): ']);
        else
            fprintf('\nUNKNOWN INPUT!\n');
        end
    end
    if ThrDistance_Deg_Mean<settings.stimObj.THRxMin % If under minimum & the experimenter fails to adjust manually, set to min automatically
        ThrDistance_Deg=settings.stimObj.THRxMin;
    end
    fprintf('\n\nTHRESHOLD SET: %.4f degrees of visual angle', ThrDistance_Deg);
    
catch
    save([settings.path.DataThr '/workspace_RecoveredByEstimateThreshold_s' num2str(settings.generalData.SubjectID)]);
    fprintf('\nSomething went wrong with the estimation of the threshold.\nWorskpace was saved. It is not possible to continue with the experiment\nPlease report!');
end


% Save to file
filename=[settings.path.DataThr '/data_s' num2str(settings.generalData.SubjectID) '.mat'];
if exist(filename,'file')
    commandwindow;
    fprintf('\nThreshold data file already exists for this subject.\nChoose (r)eplace, save a (c)opy, or do (n)ot save.\n');
    WaitSecs(.05); KbReleaseWait(-3); resp='';
    while ~strcmpi(resp,'r') && ~strcmpi(resp,'c') && ~strcmpi(resp,'n')
        resp=input('Please enter choice: ','s');
        if strcmpi(resp,'r')
            save(filename,'ThrDistance_Deg','ThrDistance_Deg_Mean', 'ThrDistance_Deg_Gumbel');
            fprintf(['\n', filename, '\n...SAVED\n\n']);
        elseif strcmpi(resp,'c')
            save([filename, '_copy'],'ThrDistance_Deg','ThrDistance_Deg_Mean', 'ThrDistance_Deg_Gumbel');
            fprintf(['\n', filename, '\n...SAVED AS COPY\n\n']);
        elseif strcmpi(resp,'n')
            fprintf(['\n', filename, '\n...NOT SAVED\n\n']);
        else
            fprintf('\nUNKNOWN INPUT!\n');
        end
    end
else
    save(filename,'ThrDistance_Deg','ThrDistance_Deg_Mean','ThrDistance_Deg_Gumbel');
end

end %function