function coords = Calculate_ProbeXY(TargetAngle_Deg, TargetRadius_Pix, Target_XY, ProbeDistance_Deg, settings, verbose)

% % USEFUL FOR DEBUG (load func arguments directly from main exp variables)
% % TargetAngle_Deg=experiment_table{trial.index,tableIndexes.StimAngle_Deg}
% % TargetRadius_Pix=  experiment_table{trial.index,tableIndexes.StimRadius_Pix}
% % Target_XY=  experiment_table{trial.index,tableIndexes.StimPos_XY}
% % ProbeDistance_Deg= trial.probedistdeg
% % verbose=1

ppd=settings.screenValues.PixelPerDegree;
XCenter=settings.screenValues.XCenter;
YCenter=settings.screenValues.YCenter;
target_hemifield=-1*sign(XCenter-Target_XY(1)); % if negative, left, if positive, right

% Stim info
currstim_radiusPix=TargetRadius_Pix;
currstim_angle_deg=TargetAngle_Deg;

% Probe position
currprobedist_deg=ProbeDistance_Deg;
currprobedist_pix=currprobedist_deg*ppd;

probe_hemifield=0; iter=1;
while probe_hemifield~=target_hemifield
    if iter==1
        whatside=randsample([-1,1],1);
    else
        whatside=whatside*(-1);
    end
    currprobe_angle_deg = currstim_angle_deg+whatside*2*asind(currprobedist_pix/(2*currstim_radiusPix));
    if currprobe_angle_deg<0; currprobe_angle_deg=currprobe_angle_deg+360;
    elseif currprobe_angle_deg>360; currprobe_angle_deg=currprobe_angle_deg-360; end
    currprobe_angle=deg2rad(currprobe_angle_deg);
    currprobepos_X=XCenter+currstim_radiusPix*cos(currprobe_angle);
    probe_hemifield=-1*sign(XCenter-currprobepos_X); % if negative, left, if positive, right
    if verbose
    fprintf('\nTarget and Probe hemifields: %.0f and %.0f, Iteraction: %.0f',target_hemifield,probe_hemifield,iter);
    end
    iter=iter+1;
end
currprobepos_Y=YCenter-currstim_radiusPix*sin(currprobe_angle);
coords=[currprobepos_X, currprobepos_Y];

end % function