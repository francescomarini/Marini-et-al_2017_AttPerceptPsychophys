function trial=DelayPeriod(settings,trial,ExpTable)

elapsed_time=GetSecs-trial.timepoint2;
XCenter=settings.screenValues.XCenter;
YCenter=settings.screenValues.YCenter;
ppd=settings.screenValues.PixelPerDegree;

tableIndexes=LoadTableIndexes;

switch trial.type
    case 'no_dist'
        trial.timepoint3=GetSecs;
        % Wait delay
        maximum_time=settings.duration.Delay;
        while elapsed_time < maximum_time-settings.screenValues.FlipInterval*0.9
            elapsed_time=GetSecs-trial.timepoint2;
        end
        trial.timepoint4=GetSecs;
        
    case 'dist'
        
        %fprintf('DIST delay')
        % Prepare coords of random dots
        elem_size_pix=settings.stimObj.DistSize_Pix;
        %howmanyelems=settings.stimObj.DistHowManyActive;
        DistCenterOfMass_XY=ExpTable{trial.index,tableIndexes.DistPos_XY};
        DistSpread_Deg=settings.stimObj.DistSpread;
        DistSpread_Pix=DistSpread_Deg*ppd;
        
        Dist2CenterOfMass_XY=ExpTable{trial.index,tableIndexes.Dist2Pos_XY};
        Dist2Spread_Deg=settings.stimObj.DistSpread;
        Dist2Spread_Pix=Dist2Spread_Deg*ppd;
        

        % Pick distracter angle random
        angles=([45:90:360; 30:90:360; 60:90:360; 90:90:360; 22.5:90:360; 67.5:90:360]);
        randar=[];
        randar(1,:)=angles(randsample(1:6,1),:);
        randar(2,:)=randar(1,:)+45;
        randar=deg2rad(randar);
        
        % Create coords of the distracter dots
        selected_elems = horzcat( ...
            [DistCenterOfMass_XY(1); DistCenterOfMass_XY(2)], ...
            [DistCenterOfMass_XY(1)+DistSpread_Pix/2*cos(randar(1,1:4)); DistCenterOfMass_XY(2)+DistSpread_Pix/2*sin(randar(1,1:4))], ...
            [DistCenterOfMass_XY(1)+DistSpread_Pix*cos(randar(2,1:4)); DistCenterOfMass_XY(2)+DistSpread_Pix*sin(randar(2,1:4))]);
        
        selected_elems_2 = horzcat( ...
            [Dist2CenterOfMass_XY(1); Dist2CenterOfMass_XY(2)], ...
            [Dist2CenterOfMass_XY(1)+Dist2Spread_Pix/2*cos(randar(1,1:4)); Dist2CenterOfMass_XY(2)+Dist2Spread_Pix/2*sin(randar(1,1:4))], ...
            [Dist2CenterOfMass_XY(1)+Dist2Spread_Pix*cos(randar(2,1:4)); Dist2CenterOfMass_XY(2)+Dist2Spread_Pix*sin(randar(2,1:4))]);
        
        
        % Color
        dist_color=repmat(transpose(settings.stimObj.DistColor),1,size(selected_elems,2));
        if ExpTable{trial.index,tableIndexes.CatchTrial}
            dist_color=settings.stimObj.DistColor_CatchTrials;
%             indccol=randsample([1:size(selected_elems,2)],6);
%             dist_color(:,indccol(1:3))=dist_color(:,indccol(1:3))-50;
%             dist_color(:,indccol(4:6))=dist_color(:,indccol(4:6))+50;
        end
        
        elapsed_time=GetSecs-trial.timepoint2;
        % Wait before presenting dist
        while elapsed_time < settings.duration.StimToDist-settings.screenValues.FlipInterval*0.9
            elapsed_time=GetSecs-trial.timepoint2;
        end

% UNCOMMENT FOR TIMING TEST  
% % % numiteracsdiff=0; % timing test        
% % % for pluto=1:100 % timing test
        Screen('DrawDots', settings.screenValues.windowPtr, selected_elems, elem_size_pix, dist_color, [], 2);
        Screen('DrawDots', settings.screenValues.windowPtr, selected_elems_2, elem_size_pix, dist_color, [], 2);
        DrawMyFixation(settings,'dot');
        eval(settings.screenValues.FlipCommand);
        trial.timepoint3=StimulusOnsetTime;
        elapsed_time=GetSecs-trial.timepoint3;
        % Present distracter
        while elapsed_time < settings.duration.Dist-settings.screenValues.FlipInterval*0.9       
            elapsed_time=GetSecs-trial.timepoint3;
        end
        
% UNCOMMENT FOR TIMING TEST        
% % %         if iteracs~=25 % to use with pluto % timing test
% % %             iteracs % timing test
% % %             numiteracsdiff=numiteracsdiff+1; % timing test
% % %         end  % timing test
% % % end %pluto % timing test
% % % PartialStimDuration=StimulusOnsetTime-trial.timepoint3;

        % Clear screen
        DrawMyFixation(settings,'dot');
        eval(settings.screenValues.FlipCommand);
        trial.timepoint4=StimulusOnsetTime;
        
% UNCOMMENT FOR TIMING TEST        
% % % StimDuration=trial.timepoint4-trial.timepoint3;
% % % fprintf('\nPartStimDuration %.3f StimDuration %.3f',PartialStimDuration,StimDuration);
       
        % Center of mass of the dots (with motion is calculated on last frame only...pretty useless. OK with static.)
        trial.distractCenterMass_XY=transpose(mean(selected_elems,2));
        
        % Wait
        elapsed_time=GetSecs-trial.timepoint4;
        while elapsed_time < settings.duration.DistToProbe-settings.screenValues.FlipInterval*0.9
            elapsed_time=GetSecs-trial.timepoint4;
        end
        
end

end % function