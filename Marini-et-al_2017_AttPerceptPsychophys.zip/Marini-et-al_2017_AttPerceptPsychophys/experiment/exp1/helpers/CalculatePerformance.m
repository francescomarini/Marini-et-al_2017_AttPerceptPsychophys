function performance = CalculatePerformance(settings, trial, performance, ExpTable)

tableIndexes=LoadTableIndexes(settings);

performance.MissesBlock=sum(isnan(cell2num(ExpTable(trial.counter-settings.generalData.numTrialsPerBlock:trial.counter-1,tableIndexes.Accuracy))));
performance.MissesTotal=performance.MissesTotal+performance.MissesBlock;
performance.MeanAcc=nanmean(cell2num(ExpTable(trial.counter-settings.generalData.numTrialsPerBlock:trial.counter-1,tableIndexes.Accuracy)));
performance.ErrorBlock=round((settings.generalData.numTrialsPerBlock-performance.MissesBlock)*(1-performance.MeanAcc));
performance.CorrBlock=round((settings.generalData.numTrialsPerBlock-performance.MissesBlock)*(performance.MeanAcc));
performance.ErrorTotal=round(performance.ErrorTotal+performance.ErrorBlock);

end %function