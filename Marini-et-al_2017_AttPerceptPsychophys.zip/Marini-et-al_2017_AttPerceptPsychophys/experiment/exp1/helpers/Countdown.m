function Countdown(screenNumber,seconds)

time=fliplr([1:1:seconds]);

for time_counter=1:length(time)
    
    Text=['Starting in ',num2str(time(time_counter)),' s. Get ready!'];
    DrawFormattedText(screenNumber, Text, 'center', 'center');
    Screen('Flip',screenNumber);
    
    WaitSecs(0.990);
    
end