function DisplayOnscreenMessage(settings,messageType,doFlip,manageRestart,completed_block,type,varargin)

% Values for messageType: 'instructions', 'ready', 'short_break', 'pause', 'goodbye', 'restart', 'cue'

if nargin==6
    switch type
        case 'dist'
            cuestring='DISTRACTION';
        case 'no_dist'
            cuestring='no distraction';
    end
end

% Shortcuts
W=settings.screenValues.windowPtr;
font=settings.screenValues.FontType;
fontstyle=settings.screenValues.FontStyle;
fontsize=settings.screenValues.FontSize;
fontcolor=settings.screenValues.TextColor;
% Xcenter=settings.screenValues.XCenter;
% Ycenter=settings.screenValues.YCenter;

% % Load image
% myimage=imread(image_file);
% imageHandle=Screen('MakeTexture', W, myimage);
% Yimage=size(myimage,1); Ximage=size(myimage,2);
% imageDstRect=[Xcenter-Ximage/2 2*Ycenter-100-Yimage Xcenter+Ximage/2 2*Ycenter-100];

% Set font
Screen('TextFont', W, font); % Select font
Screen('TextStyle', W, fontstyle); % Select style
Screen('TextSize', W, fontsize); % Select size

switch messageType
    case 'instructions'
        FormattedTextString=['\nINSTRUCTION SUMMARY' ...
            '\nTry and memorize the spatial location of the white dot that appears on' ...
            '\nthe side of the screen indicated by the arrows (ignore the other dot).' ...
            '\nAfter a short time the dots will disappear.' ...
            '\nAt this point you may see two distractors made up of clusters of dots.' ...
            '\nThe distractors will be white on most trials, but green on a few trials.', ...
            '\nNext a cursor will appear in the center of the screen that you can control using the mouse.' ...
            '\nClick on the memorized position where the white dot was located,' ...
            '\nexcept on those few trials on which the distractors were green.', ...
            '\nIn these cases, just click in the center of the screen', ...
            '\nin the location where the cursor appeared.' ...
            '\nPress the Go key to start PRACTICE\n'];
%         Screen('DrawTexture', W, imageHandle, [], imageDstRect);
    case 'ready'
        FormattedTextString=['\nEXPERIMENT READY TO START' ...
            '\n' ...
            '\n' ...
            '\n' ...
            '\nPress the Go key when ready\n'];
%         Screen('DrawTexture', W, imageHandle, [], imageDstRect);
    case 'short_break'
        FormattedTextString=['\nBREAK' ...
            '\n' ...
            '\n' ...
            '\n' ...
            '\nPress the Go key to continue\n'];
%         Screen('DrawTexture', W, imageHandle, [], imageDstRect);
    case 'pause'
        FormattedTextString=['\nBLOCK ', num2str(completed_block), ' COMPLETED' ...
            '\nPlease take a short break now' ...
            '\n' ...
            '\n' ...
            '\nPress the Go key when ready'];
%         Screen('DrawTexture', W, imageHandle, [], imageDstRect);
    case 'goodbye'
        FormattedTextString=['\nEND OF EXPERIMENT' ...
            '\n' ...
            '\n' ...
            '\n' ...
            '\nPress any key to continue\n'];
    case 'restart'
        FormattedTextString=['\nREADY TO RESTART' ...
            '\n' ...
            '\n' ...
            '\n' ...
            '\nPress the Go key to continue\n'];
    case 'cue'
        FormattedTextString=['\n' ...
            '\n' ...
            '\nType of block:' ...
            '\n' ...
            '\n', cuestring ...
            '\n' ...
            '\nPress the Go key when ready\n'];
end

DrawFormattedText(W,FormattedTextString,'center',50,fontcolor,[],[],[],1.5,[],[]);

% If requested, perform flip
if doFlip
    vbl=Screen('Flip',W);
end

% If requested, manage restart
if manageRestart
    
    if settings.generalData.NoStop
        WaitSecs(.5)
    else
        
        keyIsDown=0; KbReleaseWait;
        
        switch messageType
            case 'instructions'
                while ~keyIsDown
                    keyIsDown = CheckOnKey(settings.key.Exit, settings.key.Go, settings.generalData.ControlDeviceIndex);
                end
            case 'ready'
                while ~keyIsDown
                    keyIsDown = CheckOnKey(settings.key.Exit, settings.key.Go, settings.generalData.ControlDeviceIndex);
                end
            case 'short_break'
                while GetSecs-vbl < 5 || ~keyIsDown
                    keyIsDown = CheckOnKey(settings.key.Exit, settings.key.Go, settings.generalData.ControlDeviceIndex);
                end
            case 'pause'
                while GetSecs-vbl < 20 || ~keyIsDown
                    keyIsDown = CheckOnKey(settings.key.Exit, settings.key.Go, settings.generalData.ControlDeviceIndex);
                end
            case 'goodbye'
                while ~keyIsDown
                    keyIsDown = CheckOnKey(settings.key.Exit, 'all', -3); % Any key on any device
                end
            case 'restart'
                while ~keyIsDown
                    keyIsDown = CheckOnKey(settings.key.Exit, settings.key.Go, settings.generalData.ControlDeviceIndex);
                end
            case 'cue'
                WaitSecs(.5)
                while ~keyIsDown
                    keyIsDown = CheckOnKey(settings.key.Exit, settings.key.Go, settings.generalData.ControlDeviceIndex);
                end
        end
        KbReleaseWait;
    end
end

% Screen('Close',imageHandle);

end