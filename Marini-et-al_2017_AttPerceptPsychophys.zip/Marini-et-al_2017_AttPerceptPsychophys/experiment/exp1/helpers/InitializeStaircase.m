function [UD, targetP]=InitializeStaircase(settings)

UD=PAL_AMUD_setupUD;

% Parameters
UD = PAL_AMUD_setupUD(UD, 'Up' , settings.stimObj.THRup);
UD = PAL_AMUD_setupUD(UD, 'Down' , settings.stimObj.THRdown);
UD = PAL_AMUD_setupUD(UD, 'startValue' , settings.stimObj.THRstartvalue);
UD = PAL_AMUD_setupUD(UD, 'stepSizeUp', settings.stimObj.THRstepSizeUp);
UD = PAL_AMUD_setupUD(UD, 'stepSizeDown', settings.stimObj.THRstepSizeDown);
UD = PAL_AMUD_setupUD(UD, 'stopCriterion', settings.stimObj.THRstopCriterion);
UD = PAL_AMUD_setupUD(UD, 'stopRule', settings.stimObj.THRstopRule);
UD = PAL_AMUD_setupUD(UD, 'xMax', settings.stimObj.THRxMax);
UD = PAL_AMUD_setupUD(UD, 'xMin', settings.stimObj.THRxMin);
UD = PAL_AMUD_setupUD(UD, 'truncate', settings.stimObj.THRtruncate);

% Display
targetP = (settings.stimObj.THRstepSizeUp./(settings.stimObj.THRstepSizeUp+settings.stimObj.THRstepSizeDown)).^(1./settings.stimObj.THRdown);
message = sprintf('\nStaircase initialized! Targeted proportion correct: %6.4f',targetP);
disp(message);

end % function
