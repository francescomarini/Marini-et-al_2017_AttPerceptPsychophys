% Divide the screen in quadrants
Screen('DrawLine', screenValues.windowPtr, 0, 0, screenValues.YCenter, screenValues.XDim_px, screenValues.YCenter)
Screen('DrawLine', screenValues.windowPtr, 0, screenValues.XCenter, 0, screenValues.XCenter, screenValues.YDim_px)
eval(screenValues.FlipCommandDNC);

% Screenwide noise matrix
tzero=GetSecs;
while GetSecs-tzero<1
    noiseMatrix=255*rand(screenValues.YDim_px,screenValues.XDim_px);
    textureIndex=Screen('MakeTexture', screenValues.windowPtr, noiseMatrix);
    Screen('DrawTexture', screenValues.windowPtr, textureIndex);
    eval(screenValues.FlipCommand);
end

% Create gray background
Screen('FillRect',screenValues.windowPtr,screenValues.BackgroundColor)
eval(screenValues.FlipCommand);

%Item parameters
item_size_deg=0.2;
item_size_pix=item_size_deg*screenValues.PixelPerDegree;
% Create radial positions
radius_deg=[2.5, 4, 5.5];
angle_deg=[15, 45, 75];
radius_pix=radius_deg*screenValues.PixelPerDegree;
angle_rad=deg2rad(angle_deg);
quadrants=[1,-1; -1,-1; -1,1; 1,1];
item_coordinates=zeros(2,length(quadrants)*length(radius_deg)*length(angle_rad));
for quadranti=1:size(quadrants,1)
    for radiusi=1:size(radius_deg,2)
        for anglei=1:size(angle_rad,2)
            posi=(quadranti-1)*length(radius_deg)*length(angle_rad)+(radiusi-1)*length(angle_rad)+anglei;
            item_coordinates(1,posi)=screenValues.XCenter+quadrants(quadranti,1)*radius_pix(radiusi)*cos(angle_rad(anglei)); % Recall equation of circle in polar coordinates
            item_coordinates(2,posi)=screenValues.YCenter+quadrants(quadranti,2)*radius_pix(radiusi)*sin(angle_rad(anglei));
        end
    end
end
Screen('DrawDots', screenValues.windowPtr, item_coordinates, item_size_pix, 0);
eval(screenValues.FlipCommand);
% Create axial positions
x_distances_deg=[1.5, 3, 4.5];
y_distances_deg=[1.5, 3, 4.5];
distances_deg=combvec(x_distances_deg,y_distances_deg);
distances_pix=distances_deg*screenValues.PixelPerDegree;
quadrants=[1,-1; -1,-1; -1,1; 1,1];
item_coordinates=zeros(2,length(quadrants)*length(distances_deg));
for quadranti=1:size(quadrants,1)
    for distancesi=1:size(distances_deg,2)
        posi=(quadranti-1)*length(distances_deg)+distancesi;
        item_coordinates(1,posi)=screenValues.XCenter+quadrants(quadranti,1)*distances_pix(1,distancesi); %*cos(angle_rad(ydisti)); % Recall equation of circle in polar coordinates
        item_coordinates(2,posi)=screenValues.YCenter+quadrants(quadranti,2)*distances_pix(2,distancesi); %*sin(angle_rad(ydisti));
    end
end
Screen('DrawDots', screenValues.windowPtr, item_coordinates, item_size_pix, 0);
eval(screenValues.FlipCommand);


% Screenwide random dots
elem_size_pix=3;
howmanyelems=5000;
numgridelems_x=round(screenValues.XDim_px/elem_size_pix*0.8);
numgridelems_y=round(screenValues.YDim_px/elem_size_pix*0.8);
coords_x=linspace(0,screenValues.XDim_px,numgridelems_x);
coords_y=linspace(0,screenValues.XDim_px,numgridelems_y);
allelemcoords=combvec(coords_x,coords_y);
tzero=GetSecs;
while GetSecs-tzero<5
    selectedelems=allelemcoords(:,randsample(1:size(allelemcoords,2),howmanyelems));
    Screen('DrawDots', screenValues.windowPtr, selectedelems, elem_size_pix, 255, [], 0);
    eval(screenValues.FlipCommand);
end

