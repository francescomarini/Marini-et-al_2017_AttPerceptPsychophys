function DisplayFeedback(settings, type)

% Admitted values for "type": 'too_slow', 'incorrect'

% Shortcuts
W = settings.screenValues.windowPtr;
YCenter = settings.screenValues.YCenter;
color_tooslow=settings.screenValues.TooSlowColor;
color_incorrect=settings.screenValues.TooSlowColor;
color_correct=settings.screenValues.TextColor;
duration=settings.duration.Feedback;
downdrift=30;

% Set font
Screen('TextSize', W, settings.screenValues.FontSize);
Screen('TextFont', W, settings.screenValues.FontType);

switch type
    case 'too_slow'
        DrawFormattedText(W, 'TOO SLOW', 'center', YCenter+downdrift, color_tooslow, [], [], [], [], []);
    case 'correct'
        DrawFormattedText(W, 'CORRECT', 'center', YCenter+downdrift, color_correct, [], [], [], [], []);
    case 'incorrect'
        DrawFormattedText(W, 'INCORRECT', 'center', YCenter+downdrift, color_incorrect, [], [], [], [], []);
    case 'catch_correct'
        DrawFormattedText(W, 'CORRECT!\nYou indentified the distractors changed color and responded correctly\nPress the Go Key to continue', 'center', YCenter+downdrift, color_correct, [], [], [], [], []);
    case 'catch_incorrect'
        DrawFormattedText(W, 'INCORRECT!\nThe distractors changed colors.\nYou should have clicked in the center of the screen\nPress the Go Key to continue', 'center', YCenter+downdrift, color_incorrect, [], [], [], [], []);
end

% % Show feedback
% DrawMyFixation(settings);
% eval(settings.screenValues.FlipCommand);
% 
% % Wait feedback time
% while GetSecs-StimulusOnsetTime <= duration - settings.screenValues.FlipInterval*0.9; end
% 
% % Clear screen
% DrawMyFixation(settings);
% eval(settings.screenValues.FlipCommand);

end  % end function

