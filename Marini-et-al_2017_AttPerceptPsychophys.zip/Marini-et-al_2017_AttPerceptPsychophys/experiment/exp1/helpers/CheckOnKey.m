function [keyIsDown, secs, keypressed] = CheckOnKey(exit_key, go_key, device)

% Check keyboard for keypresses
% keypressed, exit_key and go_key are strings
% Functioning
% - if exit_key is pressed, generates an error (for catching within a try-catch block)
% - go_key is either a single key (in which case it is the only key allowed
% for Go) or the string 'all' (in which case all keys are accepted as Go keys)
% - device number -1 means Any keyboard
% - device number -2 means Any keypad
% - device number -3 means Any keyboard OR keypad

keypressed=NaN;

[keyIsDown, secs, keyCode]=KbCheck(device);

if keyIsDown % key has been pressed
    
    if sum(keyCode) > 1;
        keypressed='TooManyKeys';
    else
        keypressed=KbName(find(keyCode)); % identify key name
    end
    
    % exit requested
    if strcmp(keypressed,exit_key)
        fprintf('\n\nTHE EXIT KEY HAS BEEN PRESSED!!!\n\n');
        ListenChar(0);
    end
    
    % either all keys are okay or the go_key has been pressed
    if strcmp(go_key,'all') || strcmp(keypressed,go_key)
        keyIsDown=1;
    else
        keyIsDown=0;
    end
    
end

end % end function