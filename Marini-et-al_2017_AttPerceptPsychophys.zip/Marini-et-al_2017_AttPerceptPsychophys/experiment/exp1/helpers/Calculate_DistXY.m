function [xy_coords, polar_coords] = Calculate_DistXY(TargetAngle_Deg, TargetRadius_Pix, Target_XY, DistDistance_Deg, settings, verbose, experiment_table)

% % USEFUL FOR DEBUG (load func arguments directly from main exp variables)
% TargetAngle_Deg=experiment_table{trial.index,tableIndexes.StimAngle_Deg}
% TargetRadius_Pix=  experiment_table{trial.index,tableIndexes.StimRadius_Pix}
% Target_XY=  experiment_table{trial.index,tableIndexes.StimPos_XY}
% DistDistance_Deg= trial.distracterdistancedeg
% verbose=1

ppd=settings.screenValues.PixelPerDegree;
XCenter=settings.screenValues.XCenter;
YCenter=settings.screenValues.YCenter;
target_hemifield=-1*sign(XCenter-Target_XY(1)); % if negative, left, if positive, right

% Stim info
currstim_radiusPix=TargetRadius_Pix;
currstim_angle_deg=TargetAngle_Deg;

% Probe position
currDistracterDistance_deg=DistDistance_Deg;
currDistracterDistance_pix=currDistracterDistance_deg*ppd;

dist_hemifield=0; iter=1;
while dist_hemifield~=target_hemifield
    if iter==1
        whatside=sign(currDistracterDistance_pix);
    else
        whatside=whatside*(-1);
    end
    currdist_angle_deg = currstim_angle_deg+whatside*2*asind(currDistracterDistance_pix/(2*currstim_radiusPix));
    if currdist_angle_deg<0; currdist_angle_deg=currdist_angle_deg+360;
    elseif currdist_angle_deg>360; currdist_angle_deg=currdist_angle_deg-360; end
    currdist_angle=deg2rad(currdist_angle_deg);
    currdistpos_X=XCenter+currstim_radiusPix*cos(currdist_angle);
    dist_hemifield=-1*sign(XCenter-currdistpos_X); % if negative, left, if positive, right
    if verbose
        fprintf('\nTarget and Dist hemifields: %.0f and %.0f, Iteraction: %.0f',target_hemifield,dist_hemifield,iter);
    end
    iter=iter+1;
end
currprobepos_Y=YCenter-currstim_radiusPix*sin(currdist_angle);
xy_coords=[currdistpos_X, currprobepos_Y];
polar_coords=[currdist_angle, currstim_radiusPix/ppd];

end % function