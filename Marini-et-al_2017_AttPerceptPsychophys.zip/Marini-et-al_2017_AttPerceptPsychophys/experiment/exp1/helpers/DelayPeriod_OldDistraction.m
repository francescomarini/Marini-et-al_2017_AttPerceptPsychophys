function trial=DelayPeriod(settings,trial,ExpTable)

elapsed_time=GetSecs-trial.timepoint2;
XCenter=settings.screenValues.XCenter;
YCenter=settings.screenValues.YCenter;

switch trial.type
    case 'no_dist'
        trial.timepoint3=GetSecs;
        % Prepare probe
        DrawMyFixation(settings,'dot');
        CreateStimulus('probe',settings,trial,ExpTable);
        % Wait delay
        maximum_time=settings.duration.Delay;
        while elapsed_time < maximum_time-settings.screenValues.FlipInterval*0.9
            elapsed_time=GetSecs-trial.timepoint2;
        end
        trial.timepoint4=GetSecs;
        
    case 'dist'
        
        % Prepare coords of random dots (square shape)
        dist_color=settings.stimObj.DistColor;
        elem_size_pix=settings.stimObj.DistSize_Pix;
        howmanyelems=settings.stimObj.DistHowManyActive;       
        dist_minRadius_Pix=settings.stimObj.StimToCenterRadius_Pix-settings.stimObj.StimJitterRadius_Pix-elem_size_pix/2; % donut internal radius
        dist_maxRadius_Pix=settings.stimObj.StimToCenterRadius_Pix+settings.stimObj.StimJitterRadius_Pix+elem_size_pix/2; % donut external radius   
        coords_x=linspace(XCenter-dist_maxRadius_Pix,XCenter+dist_maxRadius_Pix,3*howmanyelems);
        coords_y=linspace(YCenter-dist_maxRadius_Pix,YCenter+dist_maxRadius_Pix,3*howmanyelems);
        
        % Wait
        while elapsed_time < settings.duration.StimToDist-settings.screenValues.FlipInterval*0.9
            elapsed_time=GetSecs-trial.timepoint2;
        end

% UNCOMMENT FOR TIMING TEST  
% % % numiteracsdiff=0; % timing test        
% % % for pluto=1:100 % timing test
        
        % Present distracter
        iteracs=0; elapsed_time=0;
        while elapsed_time < settings.duration.Dist-settings.screenValues.FlipInterval*0.9
            minsize=0; iteracs=iteracs+1; 
            if (iteracs==1 && ~settings.stimObj.DistMoving) || settings.stimObj.DistMoving % Present once if static, loop if moving 
                while minsize < howmanyelems % this loop with "minsize" avoids potential error "index out of bound" when creating selected_elems (highly unlikely but theoretically possible due to random sampling)
                    coords_xy=[Shuffle(coords_x); Shuffle(coords_y)];
                    coords_xy_circle=zeros(2,size(coords_xy,2));
                    for i=1:size(coords_xy,2)
                        if (sqrt((XCenter-coords_xy(1,i))^2+(YCenter-coords_xy(2,i))^2) >= dist_minRadius_Pix && ...
                                sqrt((XCenter-coords_xy(1,i))^2+(YCenter-coords_xy(2,i))^2) <= dist_maxRadius_Pix)
                            coords_xy_circle(:,i)=coords_xy(:,i); % Make the donut
                        end
                    end
                    coords_xy_circle=coords_xy_circle(:,coords_xy_circle(1,:)~=0 & coords_xy_circle(2,:)~=0);
                    minsize=size(coords_xy_circle,2); % because I will pick howmanyelems out of coords_xy_circle, I need to make sure that after Shuffling coords_xy_circle contains at least that many elements
                end
                selected_elems=coords_xy_circle(:,randsample([1:1:size(coords_xy_circle,2)],howmanyelems,0));
                Screen('DrawDots', settings.screenValues.windowPtr, selected_elems, elem_size_pix, dist_color, [], 2);
                DrawMyFixation(settings,'dot');
                eval(settings.screenValues.FlipCommand);
                if iteracs==1 % Take onset time at first iteraction
                    trial.timepoint3=StimulusOnsetTime;
                end  
            end
            elapsed_time=GetSecs-trial.timepoint3; 
            %alliters(iteracs)=GetSecs;
        end
        
% UNCOMMENT FOR TIMING TEST        
% % %         if iteracs~=25 % to use with pluto % timing test
% % %             iteracs % timing test
% % %             numiteracsdiff=numiteracsdiff+1; % timing test
% % %         end  % timing test
% % % end %pluto % timing test
% % % PartialStimDuration=StimulusOnsetTime-trial.timepoint3;

        % Clear screen
        DrawMyFixation(settings,'dot');
        eval(settings.screenValues.FlipCommand);
        trial.timepoint4=StimulusOnsetTime;
        
% UNCOMMENT FOR TIMING TEST        
% % % StimDuration=trial.timepoint4-trial.timepoint3;
% % % fprintf('\nPartStimDuration %.3f StimDuration %.3f',PartialStimDuration,StimDuration);

        % Prepare probe
        DrawMyFixation(settings,'dot');
        CreateStimulus('probe',settings,trial,ExpTable);
        
        % Center of mass of the dots (with motion is calculated on last frame only...pretty useless. OK with static.)
        trial.distractCenterMass_XY=transpose(mean(selected_elems,2));
        
        % Wait
        while elapsed_time < settings.duration.DistToProbe-settings.screenValues.FlipInterval*0.9
            elapsed_time=GetSecs-trial.timepoint4;
        end
        
end

end % function