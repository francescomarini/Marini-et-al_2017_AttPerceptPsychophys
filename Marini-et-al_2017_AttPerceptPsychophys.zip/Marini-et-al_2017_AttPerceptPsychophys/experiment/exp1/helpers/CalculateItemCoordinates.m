% This function returns the four coordinates [x1 x2 y1 y2] of a (squared) object for
% screen drawing. The center coordinates and item size are taken as inputs.

function current_element_position = CalculateItemCoordinates(center_coordinates, item_size_pixel)

x1=center_coordinates(1)-item_size_pixel/2;
x2=center_coordinates(1)+item_size_pixel/2;
y1=center_coordinates(2)-item_size_pixel/2;
y2=center_coordinates(2)+item_size_pixel/2;

current_element_position=[x1, y1, x2, y2];

end


