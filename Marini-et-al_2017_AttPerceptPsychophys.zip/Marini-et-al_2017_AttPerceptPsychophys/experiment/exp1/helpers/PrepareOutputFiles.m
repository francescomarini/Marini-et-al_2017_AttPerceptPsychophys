function outputFiles=PrepareOutputFiles(settings,runmode)

% Shortcuts
path=settings.path;
generalData=settings.generalData;
debug_mode=generalData.DebugMode;

if strcmp(runmode,'threshold')
    datafolder=path.DataThr;
elseif strcmp(runmode,'test')
    datafolder=path.Data;
end

% Set up files and folders for saving data
current_date=num2str(yyyymmdd(datetime('now','ConvertFrom','yyyymmdd')));
current_time=datestr(now,'HHMM');
if generalData.SubjectID<=9
% % %     current_subject_datafile_txt=fullfile(datafolder,['Subj0' num2str(generalData.SubjectID) '_' current_date '_' current_time '.txt']);
    current_subject_workspace_filename=fullfile(datafolder,['wrksp_Subj0' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
    current_subject_trials_filename=fullfile(datafolder,['trials_Subj0' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
    current_subject_exptable_filename=fullfile(datafolder,['ExpTable_Subj0' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
else
% % %     current_subject_datafile_txt=fullfile(datafolder,['Subj' num2str(generalData.SubjectID) '_' current_date '_' current_time '.txt']);
    current_subject_workspace_filename=fullfile(datafolder,['wrksp_Subj' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
    current_subject_trials_filename=fullfile(datafolder,['trials_Subj' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
    current_subject_exptable_filename=fullfile(datafolder,['ExpTable_Subj' num2str(generalData.SubjectID) '_' current_date '_' current_time '.mat']);
end
if ~exist( datafolder,'dir'); mkdir( datafolder); end
% % % if ~debug_mode && exist(current_subject_datafile_txt,'file')>=1
% % %     warning('File(s) already exist(s). New data will be appended. Press any key to continue')
% % %     KbReleaseWait; KbWait; KbReleaseWait;
% % % end

% % % % Open the datafile txt
% % % fid_datafile_txt=fopen(current_subject_datafile_txt,'w+');
% % % fprintf(fid_datafile_txt,'\n%u\t2\t3\t4\t5\t6\t7\t8\t9\t10\t11\t12\t13\t14\t15\t16\t17\t18\t19\t20\t21\t22\t23\t24\t25\t26\t27\t28\t29\t30', ...
% % %     str2double(current_time));

% % % outputFiles.datafileTxtFilename=current_subject_datafile_txt;
% % % outputFiles.datafileTxtFID=fid_datafile_txt;
outputFiles.datafileWrkspFilename=current_subject_workspace_filename;
outputFiles.datafileTrialsFilename=current_subject_trials_filename;
outputFiles.datafileExpTableFilename=current_subject_exptable_filename;

end