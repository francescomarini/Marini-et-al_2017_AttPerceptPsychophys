function CreateStimulus(argument,settings,trial,ExpTable)

% Values for argument:
% 'stim', 'mask', 'probe'

tableIndexes=LoadTableIndexes;

% Shortcuts
block_trial_counter=trial.blocktrialcounter;
current_trial_index=trial.index;
XCenter=settings.screenValues.XCenter;
YCenter=settings.screenValues.YCenter;
windowPtr=settings.screenValues.windowPtr;
XDim_px=settings.screenValues.XDim_px;
YDim_px=settings.screenValues.YDim_px;

% StimObj data
CueColor=settings.stimObj.CueColor;
CueText=ExpTable{current_trial_index,tableIndexes.CueDirection};
UnattendedStimPos_XY=ExpTable{current_trial_index,tableIndexes.UnattendedStimPos_XY};
StimPos_XY=ExpTable{current_trial_index,tableIndexes.StimPos_XY};
UnattendedStim2Pos_XY=ExpTable{current_trial_index,tableIndexes.UnattendedStim2Pos_XY};
Stim2Pos_XY=ExpTable{current_trial_index,tableIndexes.Stim2Pos_XY};
StimColor=settings.stimObj.StimColor;
StimSize_Pix=settings.stimObj.StimSize_Pix;
Position_AllStimDots=transpose([StimPos_XY; Stim2Pos_XY; UnattendedStimPos_XY; UnattendedStim2Pos_XY]);
ProbeNMPos_XY=ExpTable{current_trial_index,tableIndexes.ProbeNMPos_XY};
ProbeNM_Color=ExpTable{current_trial_index,tableIndexes.ProbeNM_Color};
ProbeMA_Color=ExpTable{current_trial_index,tableIndexes.ProbeMA_Color};
ProbeSize_Pix=settings.stimObj.ProbeSize_Pix;


%% Draw
switch argument
    case 'stim'
%           Screen('DrawDots', windowPtr, Position_AllStimDots, StimSize_Pix, StimColor, [], 2);
        Screen('DrawDots', windowPtr, StimPos_XY, StimSize_Pix, StimColor, [], 2);
        Screen('DrawDots', windowPtr, UnattendedStimPos_XY, StimSize_Pix, StimColor, [], 2);
%         Screen('DrawDots', windowPtr, Stim2Pos_XY, StimSize_Pix, StimColor, [], 2);
%         Screen('DrawDots', windowPtr, UnattendedStim2Pos_XY, StimSize_Pix, StimColor, [], 2);
    case 'probe'
        Screen('DrawDots', windowPtr, StimPos_XY, ProbeSize_Pix, ProbeMA_Color, [], 2); % matching probe
        Screen('DrawDots', windowPtr, ProbeNMPos_XY, ProbeSize_Pix, ProbeNM_Color, [], 2); % non-matching probe
%     case 'mask'
%         noiseMatrix=255*rand(YDim_px,XDim_px);
%         noisetextureIndex=Screen('MakeTexture', windowPtr, noiseMatrix);
%         Screen('DrawTexture', windowPtr, noisetextureIndex);
%         Screen('Close', noisetextureIndex);
    case 'cue'
        TextBounds = fix(Screen(windowPtr, 'TextBounds', char(CueText))/2);
        Screen('DrawText', windowPtr, CueText , XCenter-TextBounds(3), YCenter, CueColor);

end


end % function

