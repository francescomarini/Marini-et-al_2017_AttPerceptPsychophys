function [practice_experiment_table, exp_table]=CreateExperimentTable_Mixed(settings,runmode)

fprintf('\n\nCreating experiment table...');
if strcmp(runmode,'test')
    fprintf(' Mode: Test\n\n');
elseif strcmp(runmode,'threshold')
    fprintf(' Mode: Threshold\n\n');
end

% Load table index
tableIndexes=LoadTableIndexes(settings);
numColumns=settings.generalData.numColumns;

% Shortcuts
% General
numPracticeTrials=settings.generalData.numPracticeTrials;
numBlocks=settings.generalData.numBlocks;
numTrialsPerBlock=settings.generalData.numTrialsPerBlock;
numTrials=settings.generalData.numTrials;
screenValues=settings.screenValues;
XCenter=screenValues.XCenter;
YCenter=screenValues.YCenter;
ppd=screenValues.PixelPerDegree;
% Stim
StimToCenterRadius_Pix=settings.stimObj.StimToCenterRadius_Pix;
StimJitterRadius_Deg=settings.stimObj.StimJitterRadius_Deg;
StimToCenterAngles=settings.stimObj.StimToCenterAngles;
% Distractor
DistDistances=settings.stimObj.DistDistances;
% Probe
ProbeDistances_Deg=settings.stimObj.ProbeDistances_Deg;
probeColors=settings.stimObj.ProbeColor;

% Create all spatial positions for Stim
all_stimpositions=num2cell(repmat(transpose(StimToCenterAngles),numTrials/length(StimToCenterAngles),1));
all_stim2positions=zeros(length(all_stimpositions),1);
for stimposi=1:length(all_stimpositions)
	stimpos=all_stimpositions{stimposi};
    if stimpos>=0 && stimpos<=pi/2
        stim2pos=randsample(stimpos-pi/2+2*pi-StimJitterRadius_Deg:StimJitterRadius_Deg/10:stimpos-pi/2+2*pi+StimJitterRadius_Deg,1);
    elseif stimpos>=pi/2 && stimpos<=pi
        stim2pos=randsample(stimpos+pi/2-StimJitterRadius_Deg:StimJitterRadius_Deg/10:stimpos+pi/2+StimJitterRadius_Deg,1);
    elseif stimpos>=pi && stimpos<=3*pi/2
        stim2pos=randsample(stimpos-pi/2-StimJitterRadius_Deg:StimJitterRadius_Deg/10:stimpos-pi/2+StimJitterRadius_Deg,1);
    elseif stimpos>=3*pi/2
        stim2pos=randsample(stimpos+pi/2-2*pi-StimJitterRadius_Deg:StimJitterRadius_Deg/10:stimpos+pi/2-2*pi+StimJitterRadius_Deg,1);
    end
    all_stim2positions(stimposi)=stim2pos;
end
all_stim2positions=num2cell(all_stim2positions);

% Create all spatial positions for Unattended Stim and randomize (within each side)
all_unattendstimpositions=zeros(numTrials,1);
all_unattendstimpositions(cell2num(all_stimpositions)<pi/2 | cell2num(all_stimpositions)>3*pi/2,1)= ...
    Shuffle(transpose(repmat(StimToCenterAngles(StimToCenterAngles>pi/2 & StimToCenterAngles<3*pi/2),1,numTrials/length(StimToCenterAngles))));
all_unattendstimpositions(cell2num(all_stimpositions)>pi/2 & cell2num(all_stimpositions)<3*pi/2,1)= ...
    Shuffle(transpose(repmat(StimToCenterAngles(StimToCenterAngles<pi/2 | StimToCenterAngles>3*pi/2),1,numTrials/length(StimToCenterAngles))));
all_unattendstimpositions=num2cell(all_unattendstimpositions);
all_unattendedstim2positions=zeros(length(all_unattendstimpositions),1);
for stimposi=1:length(all_unattendstimpositions)
	stimpos=all_unattendstimpositions{stimposi};
    if stimpos>=0 && stimpos<=pi/2
        stim2pos=randsample(stimpos-pi/2+2*pi-StimJitterRadius_Deg:StimJitterRadius_Deg/10:stimpos-pi/2+2*pi+StimJitterRadius_Deg,1);
    elseif stimpos>=pi/2 && stimpos<=pi
        stim2pos=randsample(stimpos+pi/2-StimJitterRadius_Deg:StimJitterRadius_Deg/10:stimpos+pi/2+StimJitterRadius_Deg,1);
    elseif stimpos>=pi && stimpos<=3*pi/2
        stim2pos=randsample(stimpos-pi/2-StimJitterRadius_Deg:StimJitterRadius_Deg/10:stimpos-pi/2+StimJitterRadius_Deg,1);
    elseif stimpos>=3*pi/2
        stim2pos=randsample(stimpos+pi/2-2*pi-StimJitterRadius_Deg:StimJitterRadius_Deg/10:stimpos+pi/2-2*pi+StimJitterRadius_Deg,1);
    end
    all_unattendedstim2positions(stimposi)=stim2pos;
end
all_unattendedstim2positions=num2cell(all_unattendedstim2positions);

% Create all distances for Probe (including direction) and randmomize
all_probedistances=Shuffle(num2cell(repmat(transpose(ProbeDistances_Deg),numTrials/size(ProbeDistances_Deg,1),1),2));
%all_probedistances=settings.stimObj.ProbeDistance_Deg;

% Probe colors [note: Probe 1 is the correct response, Probe 2 is the NonMatch]
probeMAcol=[repmat(probeColors(1,:),numTrials/2,1); repmat(probeColors(2,:),numTrials/2,1)];
probeMAcol=num2cell(probeMAcol,2);
probeNMcol=flipud(probeMAcol);
% Randomize
indi=Shuffle(1:numTrials);
probeMAcol(1:numTrials)=probeMAcol(indi);
probeNMcol(1:numTrials)=probeNMcol(indi);

% Mount all (temporary)
pos_table(:,1)=all_stimpositions;
pos_table(:,2)=all_probedistances;
pos_table(:,3)=probeMAcol;
pos_table(:,4)=probeNMcol;
pos_table(:,5)=all_unattendstimpositions;
pos_table(:,6)=all_stim2positions;
pos_table(:,7)=all_unattendedstim2positions;

% Create exp_table
exp_table=cell(numTrials,numColumns);
for i=1:size(pos_table,1)
    
    % Cue side
    currstimangle=pos_table{i,1};
    if currstimangle>deg2rad(90) && currstimangle<deg2rad(270)
        currentcue='<<<';
    elseif currstimangle<deg2rad(90) || currstimangle>deg2rad(270)
        currentcue='>>>';
    else
        currentcue='???';
    end
    
    % Stim position
    tempstimpos_X=XCenter+StimToCenterRadius_Pix*cos(currstimangle); % Recall equation of circle in polar coordinates
    tempstimpos_Y=YCenter-StimToCenterRadius_Pix*sin(currstimangle); % Angles correspond to the goniometric standard circle (e.g. the 90/270 degrees line divides screen vertically left/right)
    jitter_deg=randsample(0:0.01:StimJitterRadius_Deg,1);
    jitter_angle=deg2rad(randsample(0:1:359,1));
    currstimpos_X=tempstimpos_X+(jitter_deg*ppd)*cos(jitter_angle);
    currstimpos_Y=tempstimpos_Y+(jitter_deg*ppd)*sin(jitter_angle);
    currstimposXY=[currstimpos_X, currstimpos_Y];
    currstim_radiusPix=sqrt((XCenter-currstimpos_X)^2+(YCenter-currstimpos_Y)^2); % after jittering i.e. actual radius
    sin_currstim=-1*(currstimpos_Y-YCenter);
    cos_currstim=currstimpos_X-XCenter;
    currstim_angle_deg=atan2d(sin_currstim,cos_currstim); % after jittering i.e. actual angle
    if currstim_angle_deg<0; currstim_angle_deg=currstim_angle_deg+360; end %because atan2d returns values between -180 and 180
    
    % Stim2 position
    currstim2angle=pos_table{i,6};
    currstim2pos_X=XCenter+currstim_radiusPix*cos(currstim2angle);
    currstim2pos_Y=YCenter-currstim_radiusPix*sin(currstim2angle);
    currstim2posXY=[currstim2pos_X, currstim2pos_Y];
    
    % Unattended stim position
    unattstimangle=pos_table{i,5};
    jitter_angle=randsample([0:0.1:settings.stimObj.StimJitterRadius_Deg],1);
    unattstimangle=unattstimangle+jitter_angle; % JITTER ONLY ANGLE NOT ECCENTRICITY! WE WANT SAME ECCENTRICITY AS THE TARGET!
    tempunattstimpos_X=XCenter+currstim_radiusPix*cos(unattstimangle); % Recall equation of circle in polar coordinates
    tempunattstimpos_Y=YCenter-currstim_radiusPix*sin(unattstimangle); % Angles correspond to the goniometric standard circle (e.g. the 90/270 degrees line divides screen vertically left/right)
    unattendedstimposXY=[tempunattstimpos_X, tempunattstimpos_Y]; 
    
    % Unattended stim2 position
    unattendedstim2angle=pos_table{i,7};
    unattendedstim2pos_X=XCenter+currstim_radiusPix*cos(unattendedstim2angle);
    unattstim2pos_Y=YCenter-currstim_radiusPix*sin(unattendedstim2angle);
    unattendedstim2posXY=[unattendedstim2pos_X, unattstim2pos_Y];
    
    % Probe position
    currprobedist_deg=pos_table{i,2};
%     currprobedist_pix=currprobedist_deg*ppd;
%     currprobe_angle_deg = currstim_angle_deg+signs(i)*2*asind(currprobedist_pix/(2*currstim_radiusPix));
%     if currprobe_angle_deg<0; currprobe_angle_deg=currprobe_angle_deg+360;
%     elseif currprobe_angle_deg>360; currprobe_angle_deg=currprobe_angle_deg-360; end
%     currprobe_angle=deg2rad(currprobe_angle_deg);
%     currprobepos_X=XCenter+currstim_radiusPix*cos(currprobe_angle);
%     currprobepos_Y=YCenter-currstim_radiusPix*sin(currprobe_angle);
%     currprobeposXY=[currprobepos_X, currprobepos_Y];
% % %     %     Screen('DrawDots',settings.screenValues.windowPtr, currstimposXY, 10, [0 0 128]);
% % %     %     Screen('DrawDots',settings.screenValues.windowPtr, currprobeposXY, 10, [128 0 0])
% % %     %     DrawMyFixation(settings,'dot');
% % %     %     eval(settings.screenValues.FlipCommand);
    
    % Probe color
    currprobeMAcol=pos_table{i,3};
    currprobeNMcol=pos_table{i,4};
    corrresp=find(sum([probeColors(1,1:3)==currprobeMAcol; probeColors(2,1:3)==currprobeMAcol],2)==3); % Is the probaMA color color1 or color2?
    
    % Fill in
    exp_table(i,tableIndexes.CueDirection)={currentcue};
    exp_table(i,tableIndexes.UnattendedStimPos_XY)={unattendedstimposXY};
    exp_table(i,tableIndexes.StimPos_XY)={currstimposXY};
%     exp_table(i,tableIndexes.ProbeNMPos_XY)={currprobeposXY};
    exp_table(i,tableIndexes.ProbeNMDistance_Deg)={currprobedist_deg};
%     exp_table(i,tableIndexes.ProbeNMDistance_Level)={find(ProbeDistances_Deg(:,1)==abs(currprobedist_deg))};
    exp_table(i,tableIndexes.ProbeMA_Color)={currprobeMAcol};
    exp_table(i,tableIndexes.ProbeNM_Color)={currprobeNMcol};
%    exp_table(i,tableIndexes.CorrectResponse)={corrresp};
    exp_table(i,tableIndexes.StimAngle_Deg)={currstim_angle_deg};
    exp_table(i,tableIndexes.StimRadius_Pix)={currstim_radiusPix};
    
    exp_table(i,tableIndexes.Stim2Pos_XY)={currstim2posXY};
    exp_table(i,tableIndexes.UnattendedStim2Pos_XY)={unattendedstim2posXY};
    
end

% ITI
exp_table(:,tableIndexes.ITI)=num2cell(Shuffle(linspace(settings.duration.ITI(1), settings.duration.ITI(2), numTrials))');

% Trial type, Random trial number, Practice
if strcmp(runmode,'threshold')
    % Trial type
    exp_table(:,tableIndexes.TrialType)={'no_dist'};
    % Random trial number
    sequence_exp=Shuffle(1:numTrials);
    exp_table(:,tableIndexes.RandomTrialNumber)=num2cell(sequence_exp);
    % Practice
    practice_experiment_table=exp_table(randsample(1:numTrials,numPracticeTrials),:);
    sequence_practice=Shuffle(1:numPracticeTrials);
    practice_experiment_table(:,tableIndexes.RandomTrialNumber)=num2cell(sequence_practice);
elseif strcmp(runmode,'test')
    % Trial type
    exp_table(:,tableIndexes.TrialType)=Shuffle([repmat({'dist'},numTrials/4*3,1); repmat({'no_dist'},numTrials/4,1)]);
    % Random trial number
    %     switch mod(settings.generalData.SubjectID,4) % Counterbalance block order based on subject number
    %         case 0 %DNND
    %             indexes_Dtrials=[1:numTrials/4, 3*numTrials/4+1:numTrials];
    %             indexes_Ntrials=[numTrials/4+1:3*numTrials/4];
    %         case 1 %NDDN
    %             indexes_Dtrials=[numTrials/4+1:3*numTrials/4];
    %             indexes_Ntrials=[1:numTrials/4, 3*numTrials/4+1:numTrials];
    %         case 2 % NDND
    %             indexes_Dtrials=[numTrials/4+1:2*numTrials/4, 3*numTrials/4+1:numTrials];
    %             indexes_Ntrials=[1:numTrials/4, 2*numTrials/4+1:3*numTrials/4];
    %         case 3 % DNDN
    %             indexes_Dtrials=[1:numTrials/4, 2*numTrials/4+1:3*numTrials/4];
    %             indexes_Ntrials=[numTrials/4+1:2*numTrials/4, 3*numTrials/4+1:numTrials];
    %     end
    sequence_exp=Shuffle(1:numTrials);
    indexes_Dtrials=Shuffle(num2cell(sequence_exp(1:length(sequence_exp)/4*3)));
    indexes_Ntrials=Shuffle(num2cell(sequence_exp(length(sequence_exp)/4*3+1:end)));  
    exp_table(strcmp(exp_table(:,tableIndexes.TrialType),'dist'),tableIndexes.RandomTrialNumber)=indexes_Dtrials;
    exp_table(strcmp(exp_table(:,tableIndexes.TrialType),'no_dist'),tableIndexes.RandomTrialNumber)=indexes_Ntrials;
    
    Ctrials=zeros(numTrials,1);
    Ctrials(cell2num(indexes_Dtrials(1:8)),1)=1;
    exp_table(:,tableIndexes.CatchTrial)=num2cell(Ctrials);
    
    % Distractor distance
    exp_table(strcmp(exp_table(:,tableIndexes.TrialType),'dist'),tableIndexes.DistractorDistance) = ...
    num2cell(Shuffle(repmat(transpose(DistDistances),sum((strcmp(exp_table(:,tableIndexes.TrialType),'dist')))/length(DistDistances),1)));
    exp_table(strcmp(exp_table(:,tableIndexes.TrialType),'dist'),tableIndexes.Distractor2Distance) = ...
    num2cell(Shuffle(repmat(transpose(DistDistances),sum((strcmp(exp_table(:,tableIndexes.TrialType),'dist')))/length(DistDistances),1)));

    % Practice
    practice_experiment_table_p1=exp_table(randsample(find(strcmp(exp_table(:,tableIndexes.TrialType),'dist')),numPracticeTrials/4*3),:);
    practice_experiment_table_p2=exp_table(randsample(find(strcmp(exp_table(:,tableIndexes.TrialType),'no_dist')),numPracticeTrials/4),:);
    practice_experiment_table=[practice_experiment_table_p1; practice_experiment_table_p2]; 
    practice_experiment_table(strcmp(practice_experiment_table(:,tableIndexes.TrialType),'dist'),tableIndexes.CatchTrial)=num2cell([zeros(numPracticeTrials/4*3-2,1); 1; 1]);
    sequence_practice=Shuffle(1:numPracticeTrials);
    practice_experiment_table(:,tableIndexes.RandomTrialNumber)=num2cell(sequence_practice);
    
end

% Block number
for blocki=1:numBlocks
    indexes_current_block=transpose((1+(blocki-1)*numTrialsPerBlock):(blocki*numTrialsPerBlock));
    exp_table(ismember(cell2num(exp_table(:,tableIndexes.RandomTrialNumber)),indexes_current_block),tableIndexes.BlockNumber)={blocki};
end

fprintf('\nExperiment table READY\n');

end % function

