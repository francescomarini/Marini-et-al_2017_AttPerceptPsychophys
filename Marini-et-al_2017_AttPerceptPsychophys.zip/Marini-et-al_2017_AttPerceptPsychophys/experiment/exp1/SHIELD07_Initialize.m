function settings=SHIELD07_Initialize(runmode)

if nargin>1
    error('Too many input arguments');
end

if ~strcmp(runmode,'threshold') && ~strcmp(runmode,'test')
    error(['Unidentified session type. Please choose ', char(39), 'threshold', char(39), ', ', char(39), 'test', char(39), ', or ', char(39), 'restart', char(39)]);
end


%% Set path
settings.path.Experiment=fileparts(which('SHIELD07_Run'));
settings.path.Project=fileparts(settings.path.Experiment);
settings.path.Data=fullfile(settings.path.Project,'data');
settings.path.DataThr=fullfile(settings.path.Project,'data/threshold');
addpath(genpath(settings.path.Experiment));
if ~exist(settings.path.Data,'dir'); mkdir(settings.path.Data); end
if ~exist(settings.path.DataThr,'dir'); mkdir(settings.path.DataThr); end


%% General data
% CHANGE HERE Experimenter control
settings.generalData.DebugMode=false;
settings.generalData.NoStop=false;
settings.generalData.quickMode=false;
settings.generalData.runTable={'practice', 'experiment'};
% CHANGE HERE Settings for experiment
test.numPracticeTrials=16; % number of practice trials 
test.numBlocks=12; % number of blocks in the experiment: use 
test.numTrials=384; % number of trials/block
test.numTrialsPerBlock=floor(test.numTrials/test.numBlocks);
test.PauseBeforeTrial=test.numTrialsPerBlock+1:test.numTrialsPerBlock:test.numTrials;
% CHANGE HERE Settings for threshold
threshold.numPracticeTrials=10;
threshold.numBlocks=8;
threshold.numTrials=256; % to be intended as maximum number of trials!
threshold.numTrialsPerBlock=floor(threshold.numTrials/threshold.numBlocks);
threshold.PauseBeforeTrial=threshold.numTrialsPerBlock+1:threshold.numTrialsPerBlock:threshold.numTrials;
% DO NOT CHANGE HERE Load appropriate settings depending on session
if strcmp(runmode,'threshold')
    settings.generalData.numPracticeTrials=threshold.numPracticeTrials;
    settings.generalData.numBlocks=threshold.numBlocks;
    settings.generalData.numTrialsPerBlock=threshold.numTrialsPerBlock;
    settings.generalData.numTrials=threshold.numTrials;
    settings.generalData.PauseBeforeTrial=threshold.PauseBeforeTrial;
elseif strcmp(runmode,'test')
    settings.generalData.numPracticeTrials=test.numPracticeTrials;
    settings.generalData.numBlocks=test.numBlocks;
    settings.generalData.numTrialsPerBlock=test.numTrialsPerBlock;
    settings.generalData.numTrials=test.numTrials;
    settings.generalData.PauseBeforeTrial=test.PauseBeforeTrial;
end
% % % If practice trials is an odd number make it even
% % if mod(settings.generalData.numPracticeTrials,2)
% %     settings.generalData.numPracticeTrials=settings.generalData.numPracticeTrials+1;
% % end


%% Get user inputs
settings=GetInputs(settings);

%% Set screen values
if settings.generalData.DebugMode
    settings.screenValues.Windowed=true;
else
    settings.screenValues.Windowed=false;
end
if ~strcmp(runmode,'analyzer')
    settings.screenValues.screenNumber=max(Screen('Screens'));
    % Find the color values which correspond to white and black
    white=WhiteIndex(settings.screenValues.screenNumber); white=repmat(white,1,3); settings.screenValues.White=white;
    black=BlackIndex(settings.screenValues.screenNumber); black=repmat(black,1,3); settings.screenValues.Black=black;
    gray=(white+black)/2; if round(gray)==white; gray=black; end; settings.screenValues.Gray=gray;
    % Colors
    settings.screenValues.BackgroundColor=.25*gray; % light gray
    settings.screenValues.ForegroundColor=gray; % mid gray
    settings.screenValues.TooSlowColor=[255 0 0]; % red
    % Text
    settings.screenValues.FontType='Arial';
    settings.screenValues.FontSize=36;
    settings.screenValues.FontStyle=0;
    settings.screenValues.TextColor=1.25*gray; % black
    % Fixation
    settings.screenValues.FixationSize_Pix=5; % in pixels
    settings.screenValues.FixationUpdrift_Pix=0;
    settings.screenValues.FixationPenWidth_Pix=2;
    settings.screenValues.FixationColor=1.25*gray;
    settings.screenValues.observerDistanceCM=settings.screenValues.observerDistanceInch*2.54;
end
 
    
%% Timings
settings.duration.Cue=0.5;
settings.duration.CueToStim=1;
settings.duration.Stimulus=0.2;
% settings.duration.Mask=0.2;
settings.duration.StimToDist=0.8;
settings.duration.Dist=0.4;
settings.duration.DistEachScreen=settings.duration.Dist;
settings.duration.DistToProbe=0.8;
settings.duration.Delay=settings.duration.StimToDist+settings.duration.Dist+settings.duration.DistToProbe;
settings.duration.maxResponse=5;
settings.duration.Probe=settings.duration.maxResponse;
settings.duration.ITI=[1 1.4]; % jittered between those values. From feedback offset to next stim onset
settings.duration.TooSlow=1;
settings.duration.Feedback=2;
if settings.generalData.quickMode
    duration_fieldnames=fieldnames(settings.duration);
    for fieldi=1:length(duration_fieldnames)
        eval(['settings.duration.' duration_fieldnames{fieldi} '=settings.duration.' duration_fieldnames{fieldi} '/10;']);
    end
end


%% Set Stimulus Parameters
% Cue
settings.stimObj.CueColor=1.25*gray;
% Memorized stim
settings.stimObj.StimSize_Deg=0.18;
settings.stimObj.StimColor=1.25*gray;
settings.stimObj.StimToCenterRadius_Deg=3.5;
settings.stimObj.StimToCenterAngles=deg2rad([35, 55, 125, 145, 215, 235, 305, 325]);
%settings.stimObj.StimToCenterAngles=deg2rad(linspace(30,330,64));
settings.stimObj.StimJitterRadius_Deg=0.5;
% Distracter
settings.stimObj.DistColor=settings.stimObj.StimColor;
settings.stimObj.DistSize_Deg=settings.stimObj.StimSize_Deg;
settings.stimObj.DistHowManyActive=300;
settings.stimObj.DistMoving=0;
settings.stimObj.DistDistances=[-1 0 1]; % in degrees of visual angle
settings.stimObj.DistSpread=0.5; % in degrees of visual angle
% Probe stimuli
settings.stimObj.ProbeSize_Deg=settings.stimObj.StimSize_Deg;
% Probe colors in CIE-Lch space
Lightness=45;
Chroma=100;
Hue=[140; 320]; % green and purple
StimColorsLch = [...
    Lightness Chroma Hue(1); ...
    Lightness Chroma Hue(2); ...
    ];
for i=1:length(Hue)
    StimColorsRGB(i,:) = min(max(colorspace('LCH->RGB',StimColorsLch(i,:)),0),1);
end
settings.stimObj.ProbeColor = StimColorsRGB * 255;
settings.stimObj.DistColor_CatchTrials=settings.stimObj.ProbeColor(1,:);
% Probe levels
% NOTE: settings.stimObj.ProbeLevels should be a n-by-2 vector where n is the number of desired levels. For each row, the two columns are the offsets of
% the non-matching probe in the x and y dimension, respectively, relative to the matching probe.
if strcmp(runmode,'threshold')
    %settings.stimObj.ProbeLevels_Deg=transpose(logspace(log10(0.2),log10(2),8));  
    %settings.stimObj.ProbeLevels_Deg=transpose(linspace((0.2),(2),8));
    settings.stimObj.ProbeDistances_Deg=NaN;
    % FM 3/22
    settings.stimObj.THRup=1;
    settings.stimObj.THRdown=2;
    settings.stimObj.THRstepSizeUp=0.4;
    settings.stimObj.THRstepSizeDown=0.5488*settings.stimObj.THRstepSizeUp; % see Garcia-Perez 1998
    settings.stimObj.THRstopCriterion='reversals';
    settings.stimObj.THRstopRule=40;
    settings.stimObj.THRstartvalue=1;
    settings.stimObj.THRxMax=2.5;
    settings.stimObj.THRxMin=0.2;
    settings.stimObj.THRtruncate='yes';
    settings.stimObj.THRestWithoutFirstRev=8;
    %settings.stimObj.ProbeNumTrialsPerLevel=settings.generalData.numTrials/size(settings.stimObj.ProbeLevels_Deg,1);
elseif strcmp(runmode,'test')
    % Try to locate threshold data file, else generate error
    if exist([settings.path.DataThr '/data_s' num2str(settings.generalData.SubjectID) '.mat'],'file')
        load([settings.path.DataThr '/data_s' num2str(settings.generalData.SubjectID) '.mat']);
        fprintf('\nThreshold data file loaded successfully!\n');
        if ~exist('ThrDistance_Deg','var')
            warning('Variable ThrDistanceXY_Deg NOT found for this subject. Enter manually?');
            resp=input('y/n: ');
            if strcmpi(resp,'y')
                ThrDistance_Deg=input('Degrees of visual angle of distance: ');
            else
                error('TestDistLevel_Pix not found. Experiment terminated');
            end
        else
            fprintf(['INFO: Degrees of visual angle [x, y]: ',num2str(ThrDistance_Deg),'\n']);
        end
        settings.stimObj.ProbeDistances_Deg=ThrDistance_Deg;
        WaitSecs(0.5);
        fprintf('Press any key to continue');
        KbReleaseWait(-3);
        KbWait(-3);
    else
        fprintf('\n\n');
        %         error('Threshold data file NOT found for this subject');
        settings.stimObj.ProbeDistances_Deg=1.5; % Fixed probe distance used here to determine center of mass of distactors
        fprintf('Using fixed pre-determined distances between target and probe\n\n');
    end
    settings.stimObj.ProbeNumTrialsPerLevel=40;

end
settings.threshold.ProbeNumLevels=length(settings.stimObj.ProbeDistances_Deg);


%% Set devices
% Keyboard (CONTROL DEVICE)
settings.key.Exit='e'; % key #8
settings.key.Go='space'; % key #44
settings.key.keyList=zeros(256,1); settings.key.keyList(8)=1;

% Gamepad (RESPONSE DEVICE)
if mod(settings.generalData.SubjectID,2) %odd subject number
    settings.key.Color1='b'; %left on gamepad
    settings.key.Color2='c'; %right on gamepad
else %even subject number
    settings.key.Color1='c'; %right on gamepad
    settings.key.Color2='b'; %left on gamepad
end

settings.key.ColorTexts={'GREEN','PURPLE'}; %Color1 is green, color2 is purple 
settings.key.OrderedColorKeys={settings.key.Color1, settings.key.Color2};
if all(strcmp(settings.key.OrderedColorKeys,[{'b'},{'c'}]))
    settings.key.ColorKeyLabels=[{'left'},{'right'}];
    settings.key.ColorMappingText=['Remember: left=GREEN, right=PURPLE'];
    settings.key.LeftLabelText='GREEN';
    settings.key.LeftLabelColor=settings.stimObj.ProbeColor(1,:);
    settings.key.RightLabelText='PURPLE';
    settings.key.RightLabelColor=settings.stimObj.ProbeColor(2,:);
elseif all(strcmp(settings.key.OrderedColorKeys,[{'c'},{'b'}]))
    settings.key.ColorKeyLabels=[{'right'},{'left'}];
    settings.key.ColorMappingText=['Remember: left=PURPLE, right=GREEN'];
    settings.key.LeftLabelText='PURPLE';
    settings.key.LeftLabelColor=settings.stimObj.ProbeColor(2,:);
    settings.key.RightLabelText='GREEN';
    settings.key.RightLabelColor=settings.stimObj.ProbeColor(1,:);
end


    
end % function