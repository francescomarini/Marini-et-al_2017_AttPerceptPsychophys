%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SHIELD 07 behavioral EXPERIMENT            %
%                                            %
% Script developed by:                       %
% Francesco Marini, PhD                      %
% University of California San Diego         %
% e-mail: fmarini@ucsd.edu                   %
%                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% INFO/HELP
% Use: SHIELD07_Run(runmode)
% This function runs the SHIELD07 paradigm.
% Argument "runmode" must be specified as a string.
% Allowed arguments: 'test'
% Example: SHIELD07_Run('test')

function SHIELD07_Run(runmode)

clearvars -except runmode

% Set up restarting
if strcmp(runmode,'restart')
    try
        %restart_subject_number=input('\nEnter subject number [use numbers only]\n: ');
        restart_datafolder=fullfile(fileparts(fileparts(which('SHIELD04_Run'))),'data');
        fprintf('\nOpen the most recent workspace file for this subject (filename starts with wrksp):\n');
        [filn,filp] = uigetfile(fullfile(restart_datafolder,'*.mat'),'Open the most recent workspace file for this subject... (filename starts with wrksp)');
        load(fullfile(filp,filn));
        fprintf(['\nFile loaded successfully!\n\nReady to restart subject ', num2str(settings.generalData.SubjectID), ' on trial ', num2str(trial.counter), '\n']);
        clearvars restart_* filn filp
    catch
        fprintf('\nUnable to restart :(\n');
    end
    sessions={'experiment'};
else
    fprintf('\nDo you want to do practice? (y/n, leave blank=yes):');
    KbReleaseWait;
    do_practice=input(' ','s');
    if strcmpi(do_practice,'n')
        sessions={'experiment'};
    elseif isempty(do_practice) || strcmp(do_practice,'y')
        sessions={'practice', 'experiment'};
    end
end


%% Initializations %%
PsychDefaultSetup(1); % Basic setup of PTB: AssertOpenGL and UnifyKbNames
jheapcl; % Clean Java buffer
rng('shuffle', 'twister'); % Initialize random number generator
commandwindow; % Move the focus to the command windows
initial_time=GetSecs;

% Load initial values
if ~strcmp(runmode,'restart')
    settings=SHIELD07_Initialize(runmode);
end

% Load table indexes
[tableIndexes, ~, settings]=LoadTableIndexes(settings);

% Initialize screen and Open onscreen window
settings=InitialOpenscreen(settings, 1);

% Create experiment table
if ~strcmp(runmode,'restart')
    [practice_ExpTable, ExpTable] = CreateExperimentTable_Mixed(settings,runmode);
end

% Prepare output files
settings.outputFiles=PrepareOutputFiles(settings,runmode);

% Initialize staircase
if strcmp(runmode,'threshold')
    [UD, settings.stimObj.THRtargetPerformance]=InitializeStaircase(settings);
end

% Preload functions
GetSecs;WaitSecs(0.1);KbCheck(settings.generalData.ResponseDeviceIndex);KbCheck(settings.generalData.ControlDeviceIndex);KbReleaseWait;
if ~IsWin; KbQueueCreate(settings.generalData.ControlDeviceIndex, settings.key.keyList); end

%% Display welcome screen
if ~strcmp(runmode,'restart') && strcmp(sessions{1},'practice')
    DisplayOnscreenMessage(settings,'instructions',1,1);
    Countdown(settings.screenValues.windowPtr,3);
    DrawMyFixation(settings,'dot');
    eval(settings.screenValues.FlipCommand);
    WaitSecs(1);
elseif strcmp(runmode,'restart')
    DisplayOnscreenMessage(settings,'restart',1,1);
    Countdown(settings.screenValues.windowPtr,5);
    DrawMyFixation(settings,'dot');
    eval(settings.screenValues.FlipCommand);
    WaitSecs(1);
end

% Draw fixation
DrawMyFixation(settings,'dot');
% Show fixation
eval(settings.screenValues.FlipCommand);

error_count=0; % for try/catch and debug 
exiting=0;

%% Practice/Experiment loop
for sessioni=1:length(sessions)
       
    if ~strcmp(runmode,'restart')
        % Setup session type, load exp_table, figure out num trials
        if strcmp(sessions{sessioni},'practice')
            experiment_table=practice_ExpTable;
            is_practice=1;
            numTrials=settings.generalData.numPracticeTrials;
        elseif strcmp(sessions{sessioni},'experiment')
            experiment_table=ExpTable;
            is_practice=0;
            numTrials=settings.generalData.numTrials;
        end
        % Initialize performance metrics and counters
        performance.MissesBlock=0; performance.MissesTotal=0; performance.ErrorBlock=0; performance.ErrorTotal=0;
        trial.blocktrialcounter=0; trial.startfrom=1; trial.blockcounter=1; trial.distractCenterMass_XY=NaN;
    else
        % Manage some variables if restarting
        trial.startfrom=trial.counter;
        trial.blocktrialcounter=trial.blocktrialcounter-1;
        numTrials=settings.generalData.numTrials;
        is_practice=0;
    end
    
    % Start monitoring presses of the exit key
    if ~IsWin
        KbQueueStart(settings.generalData.ControlDeviceIndex);
    end
    
    %% Trial loop
    
    %ListenChar(2); % Turn off the output to the command window
    triali = trial.startfrom;
    %trialstruct=struct([]);

    while triali <= numTrials
        
%          try
            
            % Update counters
            trial.counter=triali;
            trial.blocktrialcounter=trial.blocktrialcounter+1;
            % Figure out trial type
            trial.index=find(cell2num(experiment_table(:,tableIndexes.RandomTrialNumber))==trial.counter);
            trial.type=experiment_table{trial.index,tableIndexes.TrialType};
            trial.iscatch=experiment_table{trial.index,tableIndexes.CatchTrial};
            trial.response_XY=[NaN, NaN]; trial.response_Pol=[NaN, NaN];
            trial.StimPos_XY = experiment_table{trial.index,tableIndexes.StimPos_XY};
            trial.StimPos_Pol = xy2pol(trial.StimPos_XY, settings.screenValues.XCenter, settings.screenValues.YCenter, settings.screenValues.PixelPerDegree);
            %trial.correctresp=settings.key.OrderedColorKeys{experiment_table{trial.index,tableIndexes.CorrectResponse}};
            
            % Get probe distance for current trial and calculate probe position
            if strcmp(runmode,'threshold') && ~is_practice
                trial.probedistdeg=UD.xCurrent;
                experiment_table{trial.index,tableIndexes.ProbeNMDistance_Deg}=trial.probedistdeg; 
            elseif strcmp(runmode,'threshold') && is_practice
                trial.probedistdeg=settings.stimObj.THRstartvalue;
                experiment_table{trial.index,tableIndexes.ProbeNMDistance_Deg}=trial.probedistdeg; 
            elseif strcmp(runmode,'test')
                trial.probedistdeg=experiment_table{trial.index,tableIndexes.ProbeNMDistance_Deg};
            end
            probecoords = Calculate_ProbeXY(experiment_table{trial.index,tableIndexes.StimAngle_Deg}, ...
                experiment_table{trial.index,tableIndexes.StimRadius_Pix}, ...
                experiment_table{trial.index,tableIndexes.StimPos_XY}, ...
                trial.probedistdeg, settings, 0); %last input argument is verbose
            experiment_table{trial.index,tableIndexes.ProbeNMPos_XY}=probecoords;
            
            % Get distracter distance for current trial and calculate distracter coordinates
            if strcmp(runmode,'test') && strcmp(trial.type,'dist')
                trial.distracterdistancedeg=experiment_table{trial.index,tableIndexes.DistractorDistance};
                trial.distracter2distancedeg=experiment_table{trial.index,tableIndexes.Distractor2Distance};
                [distcoords_XY, distcoords_Pol] = Calculate_DistXY(experiment_table{trial.index,tableIndexes.StimAngle_Deg}, ...
                    experiment_table{trial.index,tableIndexes.StimRadius_Pix}, ...
                    experiment_table{trial.index,tableIndexes.StimPos_XY}, ...
                    trial.distracterdistancedeg, settings, 0, experiment_table); %last input argument is verbose         
                CoordsUnattendedStim=xy2pol(experiment_table{trial.index,tableIndexes.UnattendedStimPos_XY}, ...
                    settings.screenValues.XCenter, settings.screenValues.YCenter, settings.screenValues.PixelPerDegree);
                [dist2coords_XY, dist2coords_Pol] = Calculate_DistXY(rad2deg(CoordsUnattendedStim(1)), ...
                    CoordsUnattendedStim(2)*settings.screenValues.PixelPerDegree, ...
                    experiment_table{trial.index,tableIndexes.UnattendedStimPos_XY}, ...
                    trial.distracter2distancedeg, settings, 0, experiment_table); %last input argument is verbose
            else
                distcoords_XY=NaN; distcoords_Pol=NaN;
                dist2coords_XY=NaN; dist2coords_Pol=NaN;
            end
            experiment_table{trial.index,tableIndexes.DistPos_XY}=distcoords_XY;
            experiment_table{trial.index,tableIndexes.DistPos_Pol}=distcoords_Pol;
            experiment_table{trial.index,tableIndexes.Dist2Pos_XY}=dist2coords_XY;
            experiment_table{trial.index,tableIndexes.Dist2Pos_Pol}=dist2coords_Pol;
            
            % Check if is time for a break. If so, do it!
            %ListenChar(0); % Turn on keyboard input
            if ~is_practice && trial.counter==1 % First trial of experiment
                DisplayOnscreenMessage(settings,'ready',1,1); % Ready to start
%                 if strcmp(runmode,'test')
%                     DisplayOnscreenMessage(settings,'cue',1,1,[],trial.type);
%                 end
                if ~settings.generalData.quickMode; Countdown(settings.screenValues.windowPtr,5); end % Count down
                DrawMyFixation(settings,'dot');
                eval(settings.screenValues.FlipCommand);
                WaitSecs(1);
                
            elseif trial.counter~=1 && ismember(trial.counter,settings.generalData.PauseBeforeTrial) % Break
                jheapcl; % Clean up Java buffer
                %performance = CalculatePerformance(settings, trial, performance, experiment_table); % Calculate temp performance 
                DisplayOnscreenMessage(settings,'pause',1,1,experiment_table{trial.index,tableIndexes.BlockNumber}-1); % Display message
                trial.blocktrialcounter=1; trial.blockcounter=trial.blockcounter+1; % Adjust counters
%                 if strcmp(runmode,'test')
%                     DisplayOnscreenMessage(settings,'cue',1,1,[],trial.type);
%                 end
                if ~settings.generalData.quickMode; Countdown(settings.screenValues.windowPtr,3); end % Count down
                DrawMyFixation(settings,'dot');
                eval(settings.screenValues.FlipCommand);
                WaitSecs(1);
                
            end
            %ListenChar(2); % Turn off keyboard
                        
            % Draw and show fixation
            DrawMyFixation(settings,'dot');
            eval(settings.screenValues.FlipCommand);           
            
            % Draw cue and fixation
            CreateStimulus('cue',settings,trial,experiment_table);
            DrawMyFixation(settings,'dot');
            eval(settings.screenValues.FlipCommand);
            trial.timepoint0=StimulusOnsetTime;
            elapsed_time=GetSecs-trial.timepoint0;
            
            % Cue presentation time
            while elapsed_time < settings.duration.Cue-settings.screenValues.FlipInterval*0.9
                elapsed_time=GetSecs-trial.timepoint0;
            end
            
            % Clear screen
            DrawMyFixation(settings,'dot');
            eval(settings.screenValues.FlipCommand);
            
            % Draw Stimulus and fixation
            CreateStimulus('stim',settings,trial,experiment_table);
            DrawMyFixation(settings,'dot');
            
            % Cue-Stim delay
            while elapsed_time < settings.duration.CueToStim-settings.screenValues.FlipInterval*0.9
                elapsed_time=GetSecs-StimulusOnsetTime;
            end
            
            % Stimulus onset
            eval(settings.screenValues.FlipCommand);
            trial.timepoint1=StimulusOnsetTime;
            elapsed_time=GetSecs-trial.timepoint1;
            
            % Prepare for clearing screen
            DrawMyFixation(settings,'dot');
            % Stim presentation time
            while elapsed_time < settings.duration.Stimulus-settings.screenValues.FlipInterval*0.9
                elapsed_time=GetSecs-trial.timepoint1;
            end
            % Stim offset = Clear screen (no Mask)
            eval(settings.screenValues.FlipCommand);
            trial.timepoint2=StimulusOnsetTime;
                        
            % Delay period
            trial=DelayPeriod(settings,trial,experiment_table);
            
            % Draw labels for response mappings
            %DrawFormattedText(settings.screenValues.windowPtr, settings.key.LeftLabelText, 'left', 0, settings.key.LeftLabelColor);
            %DrawFormattedText(settings.screenValues.windowPtr, settings.key.RightLabelText, 'right', 0, settings.key.RightLabelColor);
            
            % Show response screen
            DrawMyFixation(settings,'dot');
            eval(settings.screenValues.FlipCommand);
            trial.timepoint5=StimulusOnsetTime; % resp onset start for RT
            SetMouse(settings.screenValues.XCenter, settings.screenValues.YCenter, settings.screenValues.windowPtr);
            ShowCursor('CrossHair',settings.screenValues.screenNumber);
            trial.timepoint6=GetSecs;
            
            % Wait for response
            [~,~,buttons] = GetMouse;
            while any(buttons) % if already down, wait for release
                [~,~,buttons] = GetMouse;
            end
            while ~any(buttons) % wait for press
                [x,y,buttons] = GetMouse;
            end
            trial.timepoint7=GetSecs;
            HideCursor;
            [~,~,buttons] = GetMouse;
            while any(buttons) % wait for release
                [~,~,buttons] = GetMouse;
            end
            trial.response_XY=[x, y];
            trial.response_Pol = xy2pol(trial.response_XY, settings.screenValues.XCenter, settings.screenValues.YCenter, settings.screenValues.PixelPerDegree);
            trial.rt=trial.timepoint7-trial.timepoint5;
            trial.timepoint8=GetSecs;

            % Verify if this was a catch trial
            if trial.iscatch && ~any(isnan(trial.response_XY))
                %fprintf('\nTRIAL %.0f is a catch trial',trial.counter);
                if all([x >= settings.screenValues.XCenter-settings.screenValues.PixelPerDegree/2, ...
                        x <= settings.screenValues.XCenter+settings.screenValues.PixelPerDegree/2, ...
                        y >= settings.screenValues.YCenter-settings.screenValues.PixelPerDegree/2, ...
                        y <= settings.screenValues.YCenter+settings.screenValues.PixelPerDegree/2])
                    %fprintf('\nTRIAL %.0f CATCH CORRECT',trial.counter);
                    experiment_table(trial.index,tableIndexes.CatchTrial_Acc)=num2cell(1);
                    DisplayFeedback(settings,'catch_correct');
                    eval(settings.screenValues.FlipCommand);
                    KbReleaseWait; KbWait(settings.generalData.ControlDeviceIndex); KbReleaseWait;
                else
                    %fprintf('\nTRIAL %.0f CATCH INCORRECT',trial.counter);
                    experiment_table(trial.index,tableIndexes.CatchTrial_Acc)=num2cell(0);
                    DisplayFeedback(settings,'catch_incorrect');
                    eval(settings.screenValues.FlipCommand);
                    KbReleaseWait; KbWait(settings.generalData.ControlDeviceIndex); KbReleaseWait;
                end
                % Show feedback
                trial.timepoint8=GetSecs; % feedback
                elapsed_time=GetSecs-trial.timepoint8;
            else
                ExpTable{trial.index,tableIndexes.CatchTrial_Acc}=NaN;
            end

            % Log data
            fprintf('\nTrial %.0f',trial.counter); fprintf(' RT=%.3f',trial.rt); fprintf(' X=%.2f Y=%.2f ',trial.response_XY(1),trial.response_XY(2)); % Print performance on screen
            
            experiment_table{trial.index,tableIndexes.StimPos_Pol} = trial.StimPos_Pol;
            experiment_table{trial.index,tableIndexes.Response_XY}=trial.response_XY;
            experiment_table{trial.index,tableIndexes.Response_Pol}=trial.response_Pol;
            experiment_table{trial.index,tableIndexes.ReactionTime}=trial.rt;
            experiment_table{trial.index,tableIndexes.DistractCenterMass_XY}=trial.distractCenterMass_XY;
            experiment_table{trial.index,tableIndexes.timepoint0}=trial.timepoint0;  
            experiment_table{trial.index,tableIndexes.timepoint1}=trial.timepoint1;            experiment_table{trial.index,tableIndexes.timepoint2}=trial.timepoint2;
            experiment_table{trial.index,tableIndexes.timepoint3}=trial.timepoint3;            experiment_table{trial.index,tableIndexes.timepoint4}=trial.timepoint4;
            experiment_table{trial.index,tableIndexes.timepoint5}=trial.timepoint5;            experiment_table{trial.index,tableIndexes.timepoint6}=trial.timepoint6;
            experiment_table{trial.index,tableIndexes.timepoint7}=trial.timepoint7;            experiment_table{trial.index,tableIndexes.timepoint8}=trial.timepoint8;         
            
            % If not practice save data in trialstruct
            if ~is_practice
                trialstruct(trial.counter)=trial;
                %WriteOutputFiles(trial.counter, trial.index, settings, experiment_table, 'current_trial');
            end
            
            % Clear response feedback screen
            if ExpTable{trial.index,tableIndexes.CatchTrial}
                while elapsed_time < settings.duration.Feedback-settings.screenValues.FlipInterval*0.9
                    elapsed_time=GetSecs-trial.timepoint8;
                end
                DrawMyFixation(settings,'dot');
                eval(settings.screenValues.FlipCommand);
            end
            
            % Update staircase if not practice (after having logged data!)
            if strcmp(runmode,'threshold') && ~is_practice
                UD = PAL_AMUD_updateUD(UD, respUD);
                fprintf(' Next trial intensity: %.4f UDstop: %.0f',UD.xCurrent,UD.stop);
                if UD.stop
                    triali=numTrials;
                end
            end
            
            % Wait for ITI
            elapsed_time=GetSecs-trial.timepoint8;
            while elapsed_time < experiment_table{trial.index,tableIndexes.ITI}-settings.screenValues.FlipInterval*0.9
                elapsed_time=GetSecs-trial.timepoint8; % ITI is calculated starting when feedback disappears
            end
            
            % Update trial counter
            triali=triali+1;
            
            % Check on the exit key
            if KbQueueCheck(settings.generalData.ControlDeviceIndex)
                exiting=1;
                break;
            end
            
            
%          catch
%              error_count=error_count+1;
%              fprintf('\nError on Trial %2.0f',trial.counter);
%              if error_count>=1
%                  if ~is_practice
%                      % Save output files
%                      save(settings.outputFiles.datafileWrkspFilename);
%                      save(settings.outputFiles.datafileTrialsFilename,'trialstruct');
%                      save(settings.outputFiles.datafileExpTableFilename,'experiment_table');
%                      %ListenChar(0);
%                  end
%                  error('An error occurred and the experiment was interrupted. Please try to restart.');
%              end
%          end
        
    end % end trial loop
       
end % end practice-experiment loop

%ListenChar(0); % Turn on the output to the command window

% Save output files
if ~is_practice
       save(settings.outputFiles.datafileWrkspFilename); % Save workspace
       save(settings.outputFiles.datafileTrialsFilename,'trialstruct'); % Save trials structure
       save(settings.outputFiles.datafileExpTableFilename,'experiment_table'); % Save exp table
 
    if ~exiting
% % %         % Calculate final performance
% % %         performance = CalculatePerformance(settings, trial, performance, experiment_table);
        % End of experiment
        DisplayOnscreenMessage(settings,'goodbye',1,1);
    end
end

% Close screen and files
Screen('CloseAll');
ShowCursor; % Show mouse arrow
%fclose all;

% Calculate set size
if strcmp(runmode,'threshold') && ~strcmp(trial.response,settings.key.Exit)
    EstimateThreshold(UD,settings);
end

% Time
total_time=GetSecs-initial_time;
fprintf('\n\nExperiment duration: about %.0f minutes\n',round(total_time/60));

end

