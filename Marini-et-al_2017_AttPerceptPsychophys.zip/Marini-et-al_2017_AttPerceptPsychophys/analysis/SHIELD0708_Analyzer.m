%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SHIELD0708 ANALYZER                        %
%                                            %
% Script developed by:                       %
% Francesco Marini, PhD                      %
% University of California San Diego         %
% e-mail: fmarini@ucsd.edu                   %
%                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
% close all

quote=char(39);

% Initialize
experiment='SHIELD07'; % set this to SHIELD08 as needed
ansettings=LoadSettings(experiment);
numSubj=length(ansettings.generalData.subjects);
eval(['tableIndexes=LoadTableIndexes_', experiment,';']);
FitvonMises=1;
PlotVonMises=1;
allInRadians=0;
saveToFile=1;

% Prepare for output means
output.y_nodist=nan(384/2,16);
output.y_distcent=nan(384/2,16);
output.y_distlat=nan(384/2,16);

% Prepare for output (fitting)
fitoutput.angle=cell(numSubj,4);
fitoutput.rsq=cell(numSubj,4);

% Colors
col.nodist=[120 190 255]/255;
col.distcent=[255 180 140]/255;
col.distlat=[225 110 75]/255;
col.marker_edge=[0 0 0];

%% Subject loop
for subji=1:numSubj
    
    current_subject=ansettings.generalData.subjects(subji);
    eval(['[experiment_table, expsettings, trialstruct]=LoadData_',experiment,'(ansettings,current_subject);']);
    experiment_table=sortrows(experiment_table,tableIndexes.RandomTrialNumber);
    numTrials=size(experiment_table,1);
    ppd=expsettings.screenValues.PixelPerDegree;
    
    responses_table_xy=zeros(numTrials,6); responses_table_pol=zeros(numTrials,6); responses_table_polRECALC=zeros(numTrials,6); straight_distance=zeros(numTrials,1);
    switch experiment
        case 'SHIELD07'
            % Deal with empty cells
            for triali=1:numTrials
                if isempty(experiment_table{triali,tableIndexes.DistractorDistance})
                    experiment_table{triali,tableIndexes.DistractorDistance}=NaN;
                    experiment_table{triali,tableIndexes.ReactionTime}=NaN;
                    experiment_table{triali,tableIndexes.DistPos_Pol}=[NaN NaN];
                    experiment_table{triali,tableIndexes.DistPos_XY}=[NaN NaN];
                end
            end
            for triali=1:numTrials
                responses_table_xy(triali,1:2)=experiment_table{triali,tableIndexes.StimPos_XY};
                responses_table_xy(triali,3:4)=experiment_table{triali,tableIndexes.DistPos_XY};
                responses_table_xy(triali,5:6)=experiment_table{triali,tableIndexes.Response_XY};
                
                responses_table_pol(triali,ansettings.rti.stimang:ansettings.rti.stimecc)=experiment_table{triali,tableIndexes.StimPos_Pol};
                responses_table_pol(triali,ansettings.rti.distang:ansettings.rti.distecc)=experiment_table{triali,tableIndexes.DistPos_Pol};
                responses_table_pol(triali,ansettings.rti.respang:ansettings.rti.respecc)=experiment_table{triali,tableIndexes.Response_Pol};
                
                responses_table_polRECALC(triali,ansettings.rti.stimang:ansettings.rti.stimecc)=xy2pol(experiment_table{triali,tableIndexes.StimPos_XY}, expsettings.screenValues.XCenter, expsettings.screenValues.YCenter, expsettings.screenValues.PixelPerDegree);
                responses_table_polRECALC(triali,ansettings.rti.distang:ansettings.rti.distecc)=xy2pol(experiment_table{triali,tableIndexes.DistPos_XY}, expsettings.screenValues.XCenter, expsettings.screenValues.YCenter, expsettings.screenValues.PixelPerDegree);
                responses_table_polRECALC(triali,ansettings.rti.respang:ansettings.rti.respecc)=xy2pol(experiment_table{triali,tableIndexes.Response_XY}, expsettings.screenValues.XCenter, expsettings.screenValues.YCenter, expsettings.screenValues.PixelPerDegree);
                
                straight_distance(triali,1)=sqrt((responses_table_xy(triali,1)-responses_table_xy(triali,5))^2+(responses_table_xy(triali,2)-responses_table_xy(triali,6))^2);
            end
        case 'SHIELD08'
            for triali=1:numTrials
                responses_table_xy(triali,1:2)=[experiment_table(triali,tableIndexes.StimPosX), experiment_table(triali,tableIndexes.StimPosY)];
                responses_table_xy(triali,3:4)=[experiment_table(triali,tableIndexes.DistCoMassX), experiment_table(triali,tableIndexes.DistCoMassY)];
                responses_table_xy(triali,5:6)=[experiment_table(triali,tableIndexes.ResponseX), experiment_table(triali,tableIndexes.ResponseY)];
                
                % note below that eccentricity of the Stim and Dist is recorded in experiment_table in pixels while eccentricity of the Response is in deg of visual angle
                % therefore we need to convert all to deg of visual angle. Polar Angles ARE IN RADIANS!!!
                responses_table_pol(triali,ansettings.rti.stimang:ansettings.rti.stimecc)=[experiment_table(triali,tableIndexes.StimAngle), experiment_table(triali,tableIndexes.StimEcc_Pix)/ppd];
                responses_table_pol(triali,ansettings.rti.distang:ansettings.rti.distecc)=[experiment_table(triali,tableIndexes.DistCoMassAngle), experiment_table(triali,tableIndexes.DistCoMassEcc_Pix)/ppd];
                responses_table_pol(triali,ansettings.rti.respang:ansettings.rti.respecc)=[experiment_table(triali,tableIndexes.ResponseAngle), experiment_table(triali,tableIndexes.ResponseEcc)];
                
                responses_table_polRECALC(triali,ansettings.rti.stimang:ansettings.rti.stimecc)= ...
                    xy2pol(responses_table_xy(triali,1:2), expsettings.screenValues.XCenter, expsettings.screenValues.YCenter, expsettings.screenValues.PixelPerDegree);
                responses_table_polRECALC(triali,ansettings.rti.distang:ansettings.rti.distecc)= ...
                    xy2pol(responses_table_xy(triali,3:4), expsettings.screenValues.XCenter, expsettings.screenValues.YCenter, expsettings.screenValues.PixelPerDegree);
                responses_table_polRECALC(triali,ansettings.rti.respang:ansettings.rti.respecc)= ...
                    xy2pol(responses_table_xy(triali,5:6), expsettings.screenValues.XCenter, expsettings.screenValues.YCenter, expsettings.screenValues.PixelPerDegree);
                
                straight_distance(triali,1)=sqrt((responses_table_xy(triali,1)-responses_table_xy(triali,5))^2+(responses_table_xy(triali,2)-responses_table_xy(triali,6))^2);
            end
    end
    
    % Transform angles from radians to degrees if necessary
    if ~allInRadians
        responses_table_pol(:,[ansettings.rti.stimang,ansettings.rti.distang,ansettings.rti.respang])=rad2deg(responses_table_pol(:,[1,3,5]));
    end
    
    % Calculate offset angle and distance
    DistOffsetAngleAbs=abs(responses_table_pol(:,ansettings.rti.distang)-responses_table_pol(:,ansettings.rti.stimang));
    RespOffsetAngleAbs=abs(responses_table_pol(:,ansettings.rti.respang)-responses_table_pol(:,ansettings.rti.stimang));
    RespOffsetEccentricityAbs=abs(responses_table_pol(:,ansettings.rti.respecc)-responses_table_pol(:,ansettings.rti.stimecc));
    StraightDistance=straight_distance/ppd;
    DistOffsetAngleSigned=(responses_table_pol(:,ansettings.rti.distang)-responses_table_pol(:,ansettings.rti.stimang)); %positive values =CCW, negative=CW
    RespOffsetAngleSigned=(responses_table_pol(:,ansettings.rti.respang)-responses_table_pol(:,ansettings.rti.stimang)); %positive value=resp is CCW to stim, negative=resp is CW to stim
    RespOffsetEccentricitySigned=(responses_table_pol(:,ansettings.rti.respecc)-responses_table_pol(:,ansettings.rti.stimecc)); % negative value=underestimation
    AbsoluteRespEccentricity=(responses_table_pol(:,ansettings.rti.respecc));
    
    % Logical indexes
    switch experiment
        case 'SHIELD07'
            LI.Distracter=strcmpi(experiment_table(:,tableIndexes.TrialType),'dist');
            LI.NoDistracter=strcmpi(experiment_table(:,tableIndexes.TrialType),'no_dist');
            LI.CatchTrial=cell2mat(experiment_table(:,tableIndexes.CatchTrial))==1;
            LI.DistracterCentered=DistOffsetAngleSigned==0;
        case 'SHIELD08'
            LI.Distracter=experiment_table(:,tableIndexes.Distraction)==1;
            LI.NoDistracter=experiment_table(:,tableIndexes.Distraction)==0;
            LI.CatchTrial=zeros(size(experiment_table,1),1);
            if allInRadians
                LI.DistracterCentered=DistOffsetAngleSigned>=-(expsettings.stimObj.DistAngles_Jitter) & DistOffsetAngleSigned<=(expsettings.stimObj.DistAngles_Jitter);
            elseif ~allInRadians
                LI.DistracterCentered=DistOffsetAngleSigned>=-rad2deg(expsettings.stimObj.DistAngles_Jitter) & DistOffsetAngleSigned<=rad2deg(expsettings.stimObj.DistAngles_Jitter);
            end
    end
    LI.DistracterLateral=LI.Distracter & ~LI.DistracterCentered;
    LI.DistracterCW=LI.DistracterLateral & DistOffsetAngleSigned<0; %negative==clockwise
    LI.DistracterCCW=LI.DistracterLateral & DistOffsetAngleSigned>0; % positive==counter-clockwise
    
    
    % Outliers
    if allInRadians
        noOutlierOffsetAngle=(RespOffsetAngleAbs<deg2rad(30) & RespOffsetAngleAbs>-deg2rad(30));
    elseif ~allInRadians
        noOutlierOffsetAngle=(RespOffsetAngleAbs<(30) & RespOffsetAngleAbs>-(30));
    end
    noOutlierOffsetEccentricity=(RespOffsetEccentricityAbs<2 & RespOffsetEccentricityAbs>-2);
    LI.noOutlier=noOutlierOffsetAngle & noOutlierOffsetEccentricity & ~LI.CatchTrial;
    CountOutliers(subji)=sum(~noOutlierOffsetAngle)+sum(~noOutlierOffsetEccentricity);
   
    % Calculate data for means
    output.OffsetAngle(subji,1:3)=[mean(RespOffsetAngleAbs(LI.NoDistracter & LI.noOutlier)), ...
        mean(RespOffsetAngleAbs(LI.DistracterCentered & LI.noOutlier)), ...
        mean(RespOffsetAngleAbs(LI.DistracterLateral & LI.noOutlier))];
    output.OffsetEcc(subji,1:3)=[mean(RespOffsetEccentricityAbs(LI.NoDistracter & LI.noOutlier)), ...
        mean(RespOffsetEccentricityAbs(LI.DistracterCentered & LI.noOutlier)), ...
        mean(RespOffsetEccentricityAbs(LI.DistracterLateral & LI.noOutlier))];
    output.StraightDistance(subji,1:3)=[mean(StraightDistance(LI.NoDistracter & LI.noOutlier)), ...
        mean(StraightDistance(LI.DistracterCentered & LI.noOutlier)), ...
        mean(StraightDistance(LI.DistracterLateral & LI.noOutlier))];
    output.AbsEcc(subji,1:3)=[mean(AbsoluteRespEccentricity(LI.NoDistracter & LI.noOutlier)), ...
        mean(AbsoluteRespEccentricity(LI.DistracterCentered & LI.noOutlier)), ...
        mean(AbsoluteRespEccentricity(LI.DistracterLateral & LI.noOutlier))];
    output.OffsetEccSigned(subji,1:3)=[mean(RespOffsetEccentricitySigned(LI.NoDistracter & LI.noOutlier)), ...
        mean(RespOffsetEccentricitySigned(LI.DistracterCentered & LI.noOutlier)), ...
        mean(RespOffsetEccentricitySigned(LI.DistracterLateral & LI.noOutlier))];
    
    %     % Distributions  (ANGLE)
    %     y_nodist_ang=(RespOffsetAngleAbs(LI.NoDistracter & LI.noOutlier));
    %     y_distcent_ang=(RespOffsetAngleAbs(LI.DistracterCentered & LI.noOutlier));
    %     y_distlat_ang=(RespOffsetAngleAbs(LI.DistracterLateral & LI.noOutlier));
    %     output.angle_y_nodist(1:length(y_nodist_ang),subji)=y_nodist_ang;
    %     output.angle_y_distcent(1:length(y_distcent_ang),subji)=y_distcent_ang;
    %     output.angle_y_distlat(1:length(y_distlat_ang),subji)=y_distlat_ang;
    %     % Distributions  (ECC)
    %     y_nodist_ecc=(RespOffsetEccentricityAbs(LI.NoDistracter & LI.noOutlier));
    %     y_distcent_ecc=(RespOffsetEccentricityAbs(LI.DistracterCentered & LI.noOutlier));
    %     y_distlat_ecc=(RespOffsetEccentricityAbs(LI.DistracterLateral & LI.noOutlier));
    %     output.eccentricity_y_nodist(1:length(y_nodist_ecc),subji)=y_nodist_ecc;
    %     output.eccentricity_y_distcent(1:length(y_distcent_ecc),subji)=y_distcent_ecc;
    %     output.eccentricity_y_distlat(1:length(y_distlat_ecc),subji)=y_distlat_ecc;
    %
    %     %% Plot individual cdf ANGLE
    %     subplot(3,6,subji);
    %     plot(sort(y_nodist_ang),(1:length(y_nodist_ang))/(length(y_nodist_ang)),'LineWidth',1,'Color',col.nodist);
    %     hold on;
    %     plot(sort(y_distcent_ang),(1:length(y_distcent_ang))/(length(y_distcent_ang)),'LineWidth',1,'Color',col.distcent);
    %     hold on
    %     plot(sort(y_distlat_ang),(1:length(y_distlat_ang))/(length(y_distlat_ang)),'LineWidth',1,'Color',col.distlat);
    %     tit=title(num2str(current_subject));
    %     titcolor=[output.OffsetAngle(subji,1)<output.OffsetAngle(subji,3) 0 0]+[0 0 0];
    %     set(tit,'FontSize',20,'Color',titcolor)
    %     axis([-15, 15, 0, 1])
    %     hold off;
    %
    %     % Plot individual cdf ECCENTRICITY
    %     %subplot(3,6,subji);
    %     figure;
    %     plot(sort(y_nodist_ecc),(1:length(y_nodist_ecc))/(length(y_nodist_ecc)),'LineWidth',1,'Color',col.nodist);
    %     hold on;
    %     plot(sort(y_distcent_ecc),(1:length(y_distcent_ecc))/(length(y_distcent_ecc)),'LineWidth',1,'Color',col.distcent);
    %     hold on
    %     plot(sort(y_distlat_ecc),(1:length(y_distlat_ecc))/(length(y_distlat_ecc)),'LineWidth',1,'Color',col.distlat);
    %     tit=title(num2str(current_subject));
    %     titcolor=[output.OffsetEcc(subji,1)<output.OffsetEcc(subji,3) 0 0]+[0 0 0];
    %     set(tit,'FontSize',20,'Color',titcolor)
    %     axis([-2, 2, 0, 1])
    %     hold off;
    
    %% Fit to a von Mises!
    
    if FitvonMises
        
        % First get back to radians (but if the above rad2deg conversion is not applied that means we're in rad space already!)
        if ~allInRadians
            RespOffsetAngleSignedRad=deg2rad(RespOffsetAngleSigned);
        else    
            RespOffsetAngleSignedRad=RespOffsetAngleSigned;
        end
        
        % Now sort out conditions
        %measure: angle error
        err.angle.nodist=RespOffsetAngleSignedRad(LI.NoDistracter & LI.noOutlier);
        err.angle.distCent=RespOffsetAngleSignedRad(LI.DistracterCentered & LI.noOutlier);
        err.angle.distCW=RespOffsetAngleSignedRad(LI.DistracterCW & LI.noOutlier); %positive values=repulsion, negative values=attraction
        err.angle.distCCW=RespOffsetAngleSignedRad(LI.DistracterCCW & LI.noOutlier); %positive values=attraction, negative values=repulsion
%        err.angle.distLat=[-1*err.angle.distCW; err.angle.distCCW]; % cw and ccw are collapsed here, sign is changed for distCW. Therefore POSITIVE=ATTRACTION and NEGATIVE=REPULSION
%err.angle.distLat=[err.angle.distCW; err.angle.distCCW];
        %         MeanAngleErrors(subji,1)=mean(err.angle.nodist);
%         MeanAngleErrors(subji,2)=mean(err.angle.distCent);
%         MeanAngleErrors(subji,3)=mean(err.angle.distLat);
        
        %measure: eccentricity error
        err.eccentricity.nodist=RespOffsetEccentricitySigned(LI.NoDistracter & LI.noOutlier);
        err.eccentricity.distCent=RespOffsetEccentricitySigned(LI.DistracterCentered & LI.noOutlier);
        err.eccentricity.distCW=RespOffsetEccentricitySigned(LI.DistracterCW & LI.noOutlier);
        err.eccentricity.distCCW=RespOffsetEccentricitySigned(LI.DistracterCCW & LI.noOutlier);
        err.eccentricity.distLat=[err.eccentricity.distCW; err.eccentricity.distCCW];
        
        % BINOMIAL SIGN ANALYSIS ON ECCENTRICITY ERRORS
        SignTestOutput.PValues(subji,1)=myBinomTest(sum(sign(err.eccentricity.nodist)<0),numel(err.eccentricity.nodist),0.5,'two');
        SignTestOutput.PValues(subji,2)=myBinomTest(sum(sign(err.eccentricity.distCent)<0),numel(err.eccentricity.distCent),0.5,'two');
        SignTestOutput.PValues(subji,3)=myBinomTest(sum(sign(err.eccentricity.distLat)<0),numel(err.eccentricity.distLat),0.5,'two');
        SignTestOutput.UnderestimationProb(subji,1)=sum(sign(err.eccentricity.nodist)<0)/numel(err.eccentricity.nodist);
        SignTestOutput.UnderestimationProb(subji,2)=sum(sign(err.eccentricity.distCent)<0)/numel(err.eccentricity.distCent);
        SignTestOutput.UnderestimationProb(subji,3)=sum(sign(err.eccentricity.distLat)<0)/numel(err.eccentricity.distLat);
        
        %         %     % Hist plots
        %         subplot(2,2,1); hist(err.angle.nodist,96); axis([-1.6, 1.6, 0, 10]); title('NoDist')
        %         subplot(2,2,2); hist(err.angle.distCent,96); axis([-1.6, 1.6, 0, 10]); title('Dist_Centered')
        %         subplot(2,2,3); hist(err.angle.distCW,96); axis([-1.6, 1.6, 0, 10]); title('Dist_CW')
        %         subplot(2,2,4); hist(err.angle.distCCW,96); axis([-1.6, 1.6, 0, 10]); title('Dist_CCW')
        %         figure;
        %         hist(err.angle.distLat,192);
        %         axis([-1.6, 1.6, 0, 10]);
        %         title(gca,['DistLat Mean=',num2str(mean(err.angle.distLat))]);
        
        nBins = 180;                                % # bins in the histogram
        bins = linspace(-pi,pi,nBins);             % bin centers

        measures={'angle'};
        condfnames=fieldnames(err.angle);
        switch experiment
            case 'SHIELD07'              
                conditions=condfnames([1,2,4]);
            case 'SHIELD08'
                conditions=condfnames([1,2,3,4]);
        end
        for measuresi=1:size(measures)
            curr_measure=measures{measuresi};
            for conditionsi=1:size(conditions)
                curr_cond=conditions{conditionsi};
                currErrDataVarname=['err.',curr_measure,'.',curr_cond];
                eval(['errData=',currErrDataVarname,';']);
                [mleParams, rsq]=FitVonMises_rsq(errData,0);
                eval(['fitoutput.',curr_measure,'{subji,conditionsi}=mleParams;']);
                eval(['fitrsq.',curr_measure,'{subji,conditionsi}=rsq;']);
                
                %FOR BARS
%               func = @(x) exp(mleParams(2)*cos(x-mleParams(1)))/(2*pi*besseli(0,mleParams(2)));               
%                 % Bar graph bins
%                 if ~allInRadians
%                     hx = linspace(-180,180,nBins+1);
%                 else
%                     hx = linspace(-pi,pi,nBins+1);
%                 end
%                 integ = [];
%                 for ii = 1:length(hx)-1
%                     integ = [integ,integral(func,hx(ii),hx(ii+1))];
%                 end
%                 eval(['fitoutputbins.',curr_measure,'(:,conditionsi,subji)=integ;']);
%                 % Smooth func
%                 theta = linspace(1,nBins,720);          % index for plotting a smooth 180 point function over the 25 histogram bins
%                 if ~allInRadians
%                     hxsm = linspace(-180,180,720);
%                 else
%                     hxsm = linspace(-pi,pi,720);            % index for computing integrals of 180 point function
%                 end
%                 integsm = [];
%                 for ii = 1:length(hxsm)-1
%                     integsm = [integsm,integral(func,hxsm(ii),hxsm(ii+1))];
%                 end
%                 eval(['fitoutputbinssmooth.',curr_measure,'(:,conditionsi,subji)=integsm;']);
            end
        end
        
    end
    
    
end

% Get vonMises params
if FitvonMises
    params=cell2mat(fitoutput.angle);
    if strcmp(experiment,'SHIELD07')
        mu_params=[(params(:,1)), (params(:,3)), (params(:,5))];
        k_params=[(params(:,2)), (params(:,4)), (params(:,6))];
    else strcmp(experiment,'SHIELD08')
        mu_params=[(params(:,1)), (params(:,3)), (params(:,5)), (params(:,7))];
        k_params=[(params(:,2)), (params(:,4)), (params(:,6)), (params(:,8))];
    end
    rsq_values=cell2mat(fitrsq.angle);
end

%% Save to file
if saveToFile
    save1=output.OffsetAngle;
    save2=output.OffsetEcc;
    save3=output.StraightDistance;
    save4=output.AbsEcc;
    save5=output.OffsetEccSigned;
    cd(ansettings.path.output)
    save('OffsetAngle.txt','save1','-ascii','-tabs');
    save('OffsetEcc.txt','save2','-ascii','-tabs');
    save('StraightDistance.txt','save3','-ascii','-tabs');
    save('AbsoluteEcc.txt','save4','-ascii','-tabs');
    save('OffsetEccSigned.txt','save5','-ascii','-tabs');
    
    if FitvonMises
        save('vonMisesAngle_MU.txt','mu_params','-ascii','-tabs');
        save('vonMisesAngle_K.txt','k_params','-ascii','-tabs');
        save('vonMisesRsquared.txt','rsq_values','-ascii','-tabs');
        % Save sign test output
        pvals=SignTestOutput.PValues;
        uprob=SignTestOutput.UnderestimationProb;
        save('binomSignTest_PValues.txt','pvals','-ascii','-tabs');
        save('binomSignTest_UnderestProb.txt','uprob','-ascii','-tabs')
    end
    cd(ansettings.path.analysis);
    
end

%% Group graphs
SHIELD_Graphs(output,'StraightDistance','group_averages');
SHIELD_Graphs(output,'OffsetAngle','group_averages');
SHIELD_Graphs(output,'OffsetEcc','group_averages');
% SHIELD_Graphs(output,'angle','global_dist');
% SHIELD_Graphs(output,'eccentricity','global_dist');

%% Catch trials graph
% figure
% hist(output.Catch)
% axis([0, 1, 0, 10])
% set(gca,'FontSize',20);
% xlabel('Accuracy', 'FontSize', 20);
% ylabel('Frequency (# subjects)', 'FontSize', 20);

%% Plot von Mises
if PlotVonMises
    
    colors={[120 190 255]/255, [255 180 140]/255, [225 110 75]/255, [245 90 95]/255};
    figure;
    % Bar graph params
    mu_mean=mean(mu_params,1);
    k_mean=mean(k_params,1);
    if strcmp(experiment,'SHIELD07')
        mu_std=[std(params(:,1)), std(params(:,3)), std(params(:,5))];
        k_std=[std(params(:,2)), std(params(:,4)), std(params(:,6))];
    elseif strcmp(experiment,'SHIELD08')
        mu_std=[std(params(:,1)), std(params(:,3)), std(params(:,5)), std(params(:,7))];
        k_std=[std(params(:,2)), std(params(:,4)), std(params(:,6)), std(params(:,8))];
    end
    means=[mu_mean; k_mean];
    sems=[mu_std; k_std]/(sqrt(numSubj));

    
    % Plot parameters
    for rowi=1:size(means,1)
        sph(rowi)=subplot(1,2,rowi);
        y1=means(rowi,:);
        e1=sems(rowi,:);
        x=1:length(y1);
        % Colors
        barColorMap=[colors{1}; colors{2}; colors{3}; colors{3}; colors{1}; colors{2}; colors{3}; colors{3}];
        % Plot each number one at a time, calling bar() for each y value.
        for b = 1:length(y1)
            handleToThisBarSeries(b) = bar(x(b), y1(b), 'BarWidth', 1); % plot one single bar as a separate bar series.
            set(handleToThisBarSeries(b),'FaceColor', barColorMap(b,:)); % apply the color to this bar series
            hold on;
        end
        % Errorbars
        eb=errorbar(x,y1,e1,'k.');
        box off
    end
    % Left plot axis
    sph(1).YLim=[-.04 .04];
    ylabel(sph(1),'mu')
    set(sph(1),'XTick','')
    set(sph(1),'XTickLabel','');
    set(sph(1),'FontSize',20);
    % Right plot axis
    sph(2).YLim=[0 150];
    ylabel(sph(2),'k')
    set(sph(2),'XTick','')
    set(sph(2),'XTickLabel','');
    set(sph(2),'FontSize',20);
    % Legend
    leg=legend(sph(1),{'No Dist','Centered Dist','Shifted Dist'},'Location','north');
    set(leg,'FontSize',20,'Orientation','horizontal')
    newPosition = [0.13 0.025 0.775 0.05];
    newUnits = 'normalized';
    set(leg,'Position', newPosition, 'Units', newUnits);
    box off
    
% PLOT EXAMPLE FUNC FOR REPRESENTATIVE SUBJECT  
%     Actual plot
%     Subj3 for SHIELD07
%     Subj13 for SHIELD08
%     for subji=13
%         if strcmp(experiment,'SHIELD07')
%             mu=[mean(params(subji,1)), mean(params(subji,3)), mean(mean(params(subji,[9]),2))];
%             k=[mean(params(subji,2)), mean(params(subji,4)), mean(mean(params(subji,[10]),2))];
%         elseif strcmp(experiment,'SHIELD08')
%             mu=[mean(params(subji,1)), mean(params(subji,3)), mean(mean(params(subji,[5,7]),2))];
%             k=[mean(params(subji,2)), mean(params(subji,4)), mean(mean(params(subji,[6,8]),2))];
%         end
%         figure;
%         for condi=1:3
%             let's create a von Mises with the fitted parameters for visualization
%             x = linspace(-pi,(pi)-(pi/360),720);
%             PDF
%             pred_pdf = exp(k(condi)*cos(x-mu(condi))) / (2*pi*besseli(0,k(condi)));
%             CDF
%             for i=1:length(pred_pdf)
%                 pred_cdf(i)=sum(pred_pdf(1:i));
%             end
%             pred_cdf=pred_cdf/max(pred_cdf);
%             plot(x,pred_pdf,'-','LineWidth',2,'Color',colors{condi});
%             hold on;
%         end
%         axis([-.25, .25, 0, 6]);
%         set(gca,'FontSize',20);
%         xlabel('Angle Error (rad)', 'FontSize', 20);
%         ylabel('Cumulative probability', 'FontSize', 20);
%         leg=legend('No Dist','Centered Dist','Shifted Dist','Location','northwest');
%         set(leg,'FontSize',20)
%     end
%     
%     % Function plot
%     % Func params
%     mu=mu_mean;
%     k=k_mean;
%     % Bins 
%     allbin_means=mean(fitoutputbins.angle,3);
%     allbinsm_means=mean(fitoutputbinssmooth.angle,3);
%     if strcmp(experiment,'SHIELD07')
%         binmeans=[allbin_means(:,1), allbin_means(:,2), allbin_means(:,4)];
%         binmeans_sm=[allbinsm_means(:,1), allbinsm_means(:,2), allbinsm_means(:,4)];
%     elseif strcmp(experiment,'SHIELD08')
%         binmeans=[allbin_means(:,1), allbin_means(:,2), mean(allbin_means(:,3:4),2)];
%         binmeans_sm=[allbinsm_means(:,1), allbinsm_means(:,2), mean(allbinsm_means(:,3:4),2)];
%     end
%     figure;
%     for condi=1:3
%         % Create bin histogram
%         x_bins = linspace(-pi,(pi)-(pi/360),nBins);
%         cb=bar(x_bins,binmeans(:,condi));
%         set(cb,'FaceColor','none','EdgeColor',colors{condi});
%         hold on   
%     end
%     for condi=1:3
%         % let's create a von Mises with the fitted parameters for visualization
%         x = linspace(-pi,(pi)-(pi/360),719);
%         % PDF
%         pred_pdf = exp(k(condi)*cos(x-mu(condi))) / (2*pi*besseli(0,k(condi)));
%         % CDF
%         for i=1:length(pred_pdf)
%             pred_cdf(i)=sum(pred_pdf(1:i));
%         end
%         pred_cdf=pred_cdf/max(pred_cdf);
%         pred_pdf_norm = binmeans_sm(:,condi) .* (720/nBins);
%         plothandles(condi)=plot(x,pred_pdf_norm,'-','LineWidth',4,'Color',colors{condi});
%         hold on;
%     end
%     
%     axis([-.4, .4, 0, 0.2]);
%     set(gca,'FontSize',20);
%     xlabel('Angle Error (rad)', 'FontSize', 20);
%     ylabel('Cumulative probability', 'FontSize', 20);
%     
%     leg=legend(plothandles,'No Dist','Centered Dist','Shifted Dist','Location','northwest');
%     set(leg,'FontSize',14)

    
end

