function [Xcoord, Ycoord] = pol2xy(angleRad, eccDeg, XCenter, YCenter, ppd)

eccPix=eccDeg*ppd;

Xcoord = XCenter+eccPix*cos(angleRad);
Ycoord = YCenter-eccPix*sin(angleRad);

end