function [mlePar1,rsq]=FitVonMises_rsq(errData,doPlot)

    % this is a circular gaussian (von Mises) with 2 free params
    % u is the average and k is the variability/dispersion
    mixModel = @(x,u,k) exp(k*cos(x-u))/(2*pi*besseli(0,k));
    
    % fitting options for MLE, including boundary parameters.
    opts = statset('mlecustom');
    opts.FunValCheck = 'off';
    opts.MaxIter = 2500;
    opts.MaxFunEvals = 2500;
    opts.Display = 'final';
    
    % upper and lower parameter bounds - putting bounds will keep the algorithm
    % from evaluating the pdf at nutty values (e.g., a negative SD), which will
    % help keep it from throwing errors.
    lb = [-pi/2,.1];
    ub = [pi/2,40];
    
    % this is the snippet of code that does the actual fitting. err1 is a
    % vector of recall errors (in radians) that you want to fit, sdStart and
    % pfStart are seed values for the fitting algorithm (I usually just use
    % something like [1/std(err1),0.1], and the options and boundary stuff is
    % set up above.
    sdStart=1/std(errData); muStart = 0.1;
    [mlePar1,~] = mle(errData,'pdf',mixModel,'start',[muStart,sdStart]); %,'options',opts,'lowerbound',lb,'upperbound',ub);
    
    % hack - compute rsq for fit - have to sort data into bins & # of bins
    % is an arbitrary choice, but 15 should be ok?
    bins = linspace(-pi/8,pi/8,16);                 % include n+1 bins; last one will be empty 'cause can't compute an integral higher than the largest positive error
    hstd = histc(errData,bins);
    hstd = hstd./sum(hstd);                     % normalize
    nhstd = hstd(1:end-1);                      % ditch last bin
    sst = sum((nhstd-mean(nhstd)).^2);          % total sum of squares
    
    tmp = @(x) exp(mlePar1(2)*cos(x-mlePar1(1)))/(2*pi*besseli(0,mlePar1(2)));
    pred = [];
    for ii = 1:length(nhstd)
        pred = [pred,integral(tmp,bins(ii),bins(ii+1))];
    end
    cnts = round(pred.*length(errData));       % estimated counts in each bin
    cnts = cnts./sum(cnts);                     % normalize
    sse = sum((nhstd'-cnts).^2);                   % sum of squared errors
    rsq = 1-(sse/sst);                           % rsq
    
    if doPlot
        % let's create a von Mises with the fitted parameters for visualization
        x = linspace(-pi,(pi)-(pi/360),180);
        pred = exp(mlePar1(2)*cos(x-mlePar1(1)))/(2*pi*besseli(0,mlePar1(2)));
        figure;
        plot(x,pred);
    end
    