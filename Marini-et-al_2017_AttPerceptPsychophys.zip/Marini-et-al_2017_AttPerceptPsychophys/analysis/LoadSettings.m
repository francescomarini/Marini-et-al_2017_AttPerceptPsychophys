function settings = LoadSettings(experiment)

%% Path
settings.path.project=fileparts(fileparts(which('SHIELD0708_Analyzer.m')));
settings.path.analysis=fullfile(settings.path.project,'PD_SHIELD_analyses_07-08');
settings.path.output=fullfile(settings.path.analysis,experiment,'output');
if ~exist(settings.path.output,'dir'); mkdir(settings.path.output); end;
switch experiment
    case 'SHIELD07'
        settings.path.data='YOUR PATH HERE\data\exp1';
        settings.generalData.subjects=[1:8, 10:15, 17:20]; % subjects 9 and 16 did not complete the experiment
    case 'SHIELD08'
        settings.path.data='YOUR PATH HERE\data\exp2';
        settings.generalData.subjects=[1:2, 4:7, 9:19, 85]; % subject 3 did not complete experiment, subject 8 was deemed as outlier b/c large errors
end
addpath(genpath(settings.path.data));

%% Analysis parameters
commandwindow;
% settings.generalData.subjects=input('Enter subject numbers: '); 

settings.generalData.RTcutoffInf=0.2;
settings.generalData.RTcutoffSup=5;

% Response table index
settings.rti.stimang=1;
settings.rti.stimecc=2;
settings.rti.distang=3;
settings.rti.distecc=4;
settings.rti.respang=5;
settings.rti.respecc=6;

end % function

