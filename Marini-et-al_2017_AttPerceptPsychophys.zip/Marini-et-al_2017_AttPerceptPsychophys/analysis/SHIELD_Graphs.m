function SHIELD_Graphs(output,argument,type)

col.nodist=[120 190 255]/255;
col.distcent=[255 180 140]/255;
col.distlat=[225 110 75]/255;
col.marker_edge_mean=[0 0 0];
        
switch type
    
    case 'group_averages'
        
        eval(['data=output.', argument, ';']);
        numSubj=size(data,1);
        
        figure;
        x=1:3;
        y=mean(data,1);
        e=std(data,0,1)/sqrt(numSubj);
        colors=[{col.nodist}, {col.distcent}, {col.distlat}];
        for i=1:3
            plot(linspace(i-.1,i+.1,numSubj),data(:,i),'o','MarkerSize',6,'MarkerEdgeColor',colors{i}, 'MarkerFaceColor',colors{i})
            hold on
            plot(x(i),y(i),'-bs', 'LineWidth',3, 'MarkerSize',18,'MarkerEdgeColor',col.marker_edge_mean, 'MarkerFaceColor',colors{i});
            hold on
            errorbar(x(i),y(i),e(i),'k','LineWidth',1);
            hold on
        end
        
    case 'global_dist'
        
        eval(['data.y_nodist=output.', argument, '_y_nodist;']);
        eval(['data.y_distcent=output.', argument, '_y_distcent;']);
        eval(['data.y_distlat=output.', argument, '_y_distlat;']);

        figure;
        plot(sort(data.y_nodist(~isnan(data.y_nodist))),(1:sum(sum(~isnan(data.y_nodist))))/sum(sum(~isnan(data.y_nodist))),'-','LineWidth',2,'Color',col.nodist);
        hold on
        plot(sort(data.y_distcent(~isnan(data.y_distcent))),(1:sum(sum(~isnan(data.y_distcent))))/sum(sum(~isnan(data.y_distcent))),'-','LineWidth',2,'Color',col.distcent);
        hold on
        plot(sort(data.y_distlat(~isnan(data.y_distlat))),(1:sum(sum(~isnan(data.y_distlat))))/sum(sum(~isnan(data.y_distlat))),'-','LineWidth',2,'Color',col.distlat);
%         tit=title('allSubjects');
%         set(tit,'FontSize',20)
        axis([0.01, 20, 0, 1])

end


switch argument
    
    case 'OffsetAngle'
        axis([0.5, 3.5, 0, 10])
        set(gca,'FontSize',20);
        %xlabel('Condition', 'FontSize', 20);
        ylabel('Angle Error (deg polar angle)', 'FontSize', 20);
        set(gca,'XTick',1:1:3);
        set(gca,'XTickLabel',{'No Dist','Centered Dist','Shifted Dist'});
    case 'angle'
        axis([0, 20, 0, 1])
        set(gca,'FontSize',20);
        xlabel('Angle Error (deg polar angle)', 'FontSize', 20);
        ylabel('Cumulative probability', 'FontSize', 20);
        leg=legend('No Dist','Centered Dist','Shifted Dist','Location','southeast');
        set(leg,'FontSize',20)
    case 'OffsetEcc'
        axis([0.5, 3.5, 0, 0.8])
        set(gca,'FontSize',20);
        %xlabel('Condition', 'FontSize', 20);
        ylabel('Eccentricity Error (deg visual angle)', 'FontSize', 20);
        set(gca,'XTick',1:1:3);
        set(gca,'XTickLabel',{'No Dist','Centered Dist','Shifted Dist'});
    case 'eccentricity'
        axis([0, 2, 0, 1])
        set(gca,'FontSize',20);
        xlabel('Eccentricity Error (deg visual angle)', 'FontSize', 20);
        ylabel('Cumulative probability', 'FontSize', 20);
        leg=legend('No Dist','Centered Dist','Shifted Dist','Location','southeast');
        set(leg,'FontSize',20)
    case 'StraightDistance'
        axis([0.5, 3.5, 0, 1])
        set(gca,'FontSize',20);
        %xlabel('Condition', 'FontSize', 20);
        ylabel('Straight Distance (deg visual angle)', 'FontSize', 20);
        set(gca,'XTick',1:1:3);
        set(gca,'XTickLabel',{'No Dist','Centered Dist','Shifted Dist'});
end

box off

hold off;