function [tableIndexes, tableNames, settings]=LoadTableIndexes_SHIELD07(settings)

%% Indexes of columns within experiment_table

tableIndexes={};
tableIndexes.SubjectID=1;
tableIndexes.BlockNumber=2;
tableIndexes.OrderedTrialNumber=3;
tableIndexes.RandomTrialNumber=4;
tableIndexes.TrialType=5; % no-distracter (threshold) or distracter
tableIndexes.StimPos_XY=6;
tableIndexes.StimAngle_Deg=7;
tableIndexes.StimRadius_Pix=8;
tableIndexes.ProbeNMPos_XY=9;
tableIndexes.ProbeNMDistance_Deg=10;
tableIndexes.ProbeNM_Color=11;
tableIndexes.ProbeMA_Color=12;
tableIndexes.StimPos_Pol=13;
tableIndexes.Response_XY=14;
tableIndexes.Response_Pol=15;
tableIndexes.ReactionTime=16;
tableIndexes.CueDirection=17;
tableIndexes.UnattendedStimPos_XY=18;
tableIndexes.ITI=19;
tableIndexes.timepoint0=20;
tableIndexes.timepoint1=21;
tableIndexes.timepoint2=22;
tableIndexes.timepoint3=23;
tableIndexes.timepoint4=24;
tableIndexes.timepoint5=25;
tableIndexes.timepoint6=26;
tableIndexes.timepoint7=27;
tableIndexes.timepoint8=28;
tableIndexes.timepoint9=29;
tableIndexes.DistractCenterMass_XY=30;
tableIndexes.Stim2Pos_XY=31;
tableIndexes.UnattendedStim2Pos_XY=32;
tableIndexes.DistractorDistance=33;
tableIndexes.DistPos_XY=34;
tableIndexes.DistPos_Pol=35;
tableIndexes.CatchTrial=36;
tableIndexes.CatchTrial_Acc=37;
tableIndexes.Dist2Pos_XY=38;
tableIndexes.Dist2Pos_Pol=39;
tableIndexes.Distractor2Distance=40;

tableNames=fieldnames(tableIndexes);

settings.generalData.numColumns=size(fieldnames(tableIndexes),1);

end