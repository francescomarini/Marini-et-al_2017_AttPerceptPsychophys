function PolCoords = xy2pol(xy, XCenter, YCenter, ppd)

x=xy(1); y=xy(2);

radiusPix=sqrt((XCenter-x)^2+(YCenter-y)^2);
radiusDeg=radiusPix/ppd;

sin_currstim=-1*(y-YCenter);
cos_currstim=x-XCenter;
angleDeg=atan2d(sin_currstim,cos_currstim); % after jittering i.e. actual angle
if angleDeg<0; angleDeg=angleDeg+360; end %because atan2d returns values between -180 and 180
angleRad=deg2rad(angleDeg);

PolCoords=[angleRad, radiusDeg];

end