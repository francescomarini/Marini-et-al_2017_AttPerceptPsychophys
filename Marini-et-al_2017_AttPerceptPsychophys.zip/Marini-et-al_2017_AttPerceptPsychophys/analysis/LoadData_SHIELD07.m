function [experiment_table, settings, trialstruct]=LoadData_SHIELD07(ansettings,current_subject)

    quote=char(39);
    
    data_path=ansettings.path.data;
    
    % Figure out data file name
    if current_subject<10; subjstr=strcat('0',num2str(current_subject));
    else subjstr=num2str(current_subject); end
    datafile=dir([data_path, strcat('/wrksp_Subj',subjstr,'*')]);
    
    load(fullfile(data_path,datafile.name));
    
    data=experiment_table;
    

end