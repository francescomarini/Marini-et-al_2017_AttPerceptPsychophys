function angleInDegrees = rad2deg(angleInRadians)
% RAD2DEG Convert angles from radians to degrees
%
%   angleInDegrees = RAD2DEG(angleInRadians) converts angle units from
%   radians to degrees for each element of angleInRadians. In the case of
%   complex input, real and imaginary parts are converted separately.
%
%   Example:
%      % Convert a great-circle distance of 2500 kilometers to a spherical
%      % distance in degrees.
%      Re = 6371;  % Mean radius of Earth in km
%      sphericalDistance = rad2deg(2500 / Re)
%
%   Class support for input angleInRadians:
%      float: double, single
%
%   See also: DEG2RAD

% Copyright 1996-2014 The MathWorks, Inc.

angleInDegrees = (180/pi) * angleInRadians;
